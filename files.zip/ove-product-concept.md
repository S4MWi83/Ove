# Ové — Product Concept Document
*Last updated: March 2026*

---

## Core Idea
An investing app that gets a complete beginner started in under 2 minutes, from €10, with zero jargon. Built for Europeans who keep saying "I'll start next month" but never do.

**Tagline:** From someday to today.

---

## The Problem
Only 9% of Europeans own stock directly (ECB). The barrier isn't money or knowledge — it's friction. Every existing app (Trading 212, eToro, Revolut) was built for people who already know what they're doing. They overwhelm beginners with hundreds of options before they've invested a single euro.

---

## The Solution
One decision. One portfolio. One minute.

Ové removes every unnecessary choice from the onboarding experience. The user picks a risk level, deposits €1, and they're investing. That's it.

---

## Product Type
Web app (browser-based, mobile responsive). No app store required to start.

---

## Onboarding Flow (7 screens)

1. **Welcome** — Brand promise, 3 key stats
2. **Name** — First name only
3. **Goal** — 4 options: Emergency fund / Future / Retirement / Grow money
4. **Amount** — Slider + quick-pick, starts €10, minimum €100
5. **Portfolio** — 3 options (see below)
6. **Confirm** — Summary + 10-year projection
7. **Done** — Celebration screen

---

## Core Portfolios (3 options)

| Name | Risk | Allocation | Est. Return |
|------|------|------------|-------------|
| Steady | Low | 70% Bonds, 20% Stocks, 10% Cash | ~4–6%/yr |
| Balanced | Medium | 60% Stocks, 30% Bonds, 10% Cash | ~7–9%/yr |
| Growth | Higher | 90% Stocks, 8% Bonds, 2% Cash | ~10–12%/yr |

Users never pick individual stocks or ETFs. Ové handles allocation automatically based on their choice.

---

## User Journey & Tiers

### Beginner Ové (Month 0)
- Sign up in under 2 minutes
- Pick Steady, Balanced or Growth
- Invest from €100
- No stock picking, no complexity
- Zero decisions after setup

### Experienced Ové (Month 6+)
- After 6 consecutive months of investing, users unlock **Experienced Ové**
- Triggered by a milestone notification:
  *"6 months ago you took your first step. Look at you now. Ready to take the wheel?"*
- Users can **choose** to unlock the Experienced feature — it's optional, not forced
- Experienced users keep their core portfolio AND can add individual stocks/ETFs alongside it
- Full control for those who want it, without overwhelming those who don't

**Why 6 months:**
- Users have built a genuine investing habit
- They're confident enough to make their own decisions
- They're emotionally invested in the product — less likely to churn
- Natural upsell moment for Ové Plus


---

## Portfolio Transparency

From day one users can see exactly what their money is invested in — but presented in plain English, never raw financial data.

**What a beginner sees in their dashboard:**

> **Your Growth portfolio contains:**
> - 🌍 Global Stocks — 90% — *Top companies worldwide like Apple, Microsoft, Amazon*
> - 📊 Bonds — 8% — *Government and corporate bonds for stability*
> - 💵 Cash — 2% — *Always accessible*

**If they tap into Global Stocks they see:**
> *Your money is spread across 1,500+ companies in 23 countries. No single company makes up more than 4% of your portfolio.*

**Design principle:**
- Plain English first, financial jargon never
- Let users dig deeper if they want — never force it
- Ticker symbols and percentages are hidden by default
- Gradually educates users about investing through their own portfolio
- Builds confidence — "I own a tiny piece of Apple" is exciting
- Naturally leads users toward Experienced Ové after 6 months

---

## Business Model

- **0.5% AUM fee** — scales with user portfolio size
- **Ové Plus €4.99/month** — auto-investing, tax reports, multi-portfolio
- **Referral/partner revenue** from regulated broker infrastructure

---

## Technical Infrastructure

- **Frontend:** Next.js, Tailwind CSS
- **Backend:** Supabase (auth + database)
- **Deployment:** Vercel
- **Broker partner:** Saxo OpenAPI, DriveWealth or Scalable Capital (white-label)
- **KYC:** Onfido or Veriff
- **Payments:** Treezor or Swan
- **Regulatory:** MiFID II via broker partner licence

---

## Key Differentiators

1. Fastest onboarding in Europe — under 2 minutes
2. €10 minimum — lowest barrier to entry
3. 3 portfolios, not 300 — zero overwhelm
4. No bank switching required
5. Grows with the user — Beginner → Experienced journey
6. Built for beginners, not traders

---

## What Ové is NOT
- Not a trading platform
- Not a bank
- Not built for experts
- Not trying to compete with Trading 212 or eToro on features

---

## Competitive Landscape

| App | Simplicity | Beginner Focus | Europe | Verdict |
|-----|------------|----------------|--------|---------|
| Trading 212 | Medium | Low | ✅ | Too complex |
| eToro | Low | Low | ✅ | Built for traders |
| Revolut | Medium | Low | ✅ | Finance super-app, not focused |
| Lightyear | Medium | Medium | ✅ | Closest rival |
| Acorns | High | High | ❌ US only | Best comparison |
| **Ové** | **Very High** | **Very High** | ✅ | **Unoccupied position** |

---

## The Robinhood Parallel
Robinhood proved zero friction gets people investing — 20 million users, zero commission fees. But it drifted into complexity. Europe never got that first moment. Ové is that moment for Europe.

---

## Vision
Every European who wants to invest but hasn't started yet — that's our user. Not the trader. Not the expert. The person who keeps saying someday. We turn someday into today.
