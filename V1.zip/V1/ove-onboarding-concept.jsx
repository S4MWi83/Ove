import { useState } from "react";

const steps = [
  { id: "welcome", label: "Welcome", number: 0 },
  { id: "name", label: "Your name", number: 1 },
  { id: "goal", label: "Your goal", number: 2 },
  { id: "amount", label: "First investment", number: 3 },
  { id: "portfolio", label: "Your portfolio", number: 4 },
  { id: "confirm", label: "Confirm", number: 5 },
  { id: "done", label: "Started", number: 6 },
];

const portfolios = [
  {
    id: "safe",
    name: "Steady",
    risk: "Low risk",
    description: "Mostly bonds & stable assets. Slow and reliable growth.",
    return: "~4–6% / year",
    color: "#3b82f6",
    icon: "◎",
    split: [{ label: "Bonds", pct: 70 }, { label: "Stocks", pct: 20 }, { label: "Cash", pct: 10 }],
  },
  {
    id: "balanced",
    name: "Balanced",
    risk: "Medium risk",
    description: "Mix of stocks and bonds. The most popular choice.",
    return: "~7–9% / year",
    color: "#6366f1",
    icon: "◈",
    split: [{ label: "Stocks", pct: 60 }, { label: "Bonds", pct: 30 }, { label: "Cash", pct: 10 }],
  },
  {
    id: "growth",
    name: "Growth",
    risk: "Higher risk",
    description: "Mostly global stocks. More ups and downs, more potential.",
    return: "~10–12% / year",
    color: "#8b5cf6",
    icon: "◇",
    split: [{ label: "Stocks", pct: 90 }, { label: "Bonds", pct: 8 }, { label: "Cash", pct: 2 }],
  },
];

const goals = [
  { id: "emergency", label: "Build an emergency fund", icon: "🛡️" },
  { id: "future", label: "Save for the future", icon: "🌱" },
  { id: "retire", label: "Start planning for retirement", icon: "☀️" },
  { id: "grow", label: "Just make my money grow", icon: "📈" },
];

function ProgressBar({ current, total }) {
  return (
    <div style={{ display: "flex", gap: 4, marginBottom: 40 }}>
      {Array.from({ length: total }).map((_, i) => (
        <div key={i} style={{
          flex: 1, height: 3, borderRadius: 2,
          background: i < current ? "#3b82f6" : "#e0e8f0",
          transition: "background 0.4s ease",
        }} />
      ))}
    </div>
  );
}

function Screen({ children, title, subtitle }) {
  return (
    <div style={{
      animation: "fadeSlide 0.35s ease forwards",
    }}>
      <style>{`
        @keyframes fadeSlide {
          from { opacity: 0; transform: translateY(16px); }
          to { opacity: 1; transform: translateY(0); }
        }
      `}</style>
      {title && (
        <div style={{ marginBottom: 32 }}>
          <h2 style={{ margin: "0 0 10px", fontSize: "clamp(22px, 4vw, 30px)", fontWeight: 400, letterSpacing: "-0.02em", color: "#0a1628" }}>
            {title}
          </h2>
          {subtitle && <p style={{ margin: 0, fontSize: 15, color: "#6b8aaa", lineHeight: 1.6 }}>{subtitle}</p>}
        </div>
      )}
      {children}
    </div>
  );
}

function Button({ onClick, children, variant = "primary", disabled }) {
  return (
    <button onClick={onClick} disabled={disabled} style={{
      width: "100%",
      padding: "16px",
      borderRadius: 12,
      border: "none",
      background: variant === "primary"
        ? (disabled ? "#c8d8e8" : "linear-gradient(135deg, #1a3a8f, #3b82f6)")
        : "transparent",
      color: variant === "primary" ? "white" : "#3b82f6",
      fontSize: 16,
      fontFamily: "'Georgia', serif",
      cursor: disabled ? "not-allowed" : "pointer",
      letterSpacing: "0.01em",
      transition: "opacity 0.2s",
      marginTop: 8,
    }}>
      {children}
    </button>
  );
}

export default function OveOnboarding() {
  const [step, setStep] = useState(0);
  const [data, setData] = useState({ name: "", goal: "", amount: 10, portfolio: "balanced" });
  const totalSteps = 5;

  const next = () => setStep(s => s + 1);
  const set = (key, val) => setData(d => ({ ...d, [key]: val }));

  const selectedPortfolio = portfolios.find(p => p.id === data.portfolio);

  const projectedValue = (amount, years, rate) => {
    return (amount * Math.pow(1 + rate, years)).toFixed(0);
  };

  return (
    <div style={{
      minHeight: "100vh",
      background: "#f0f4f8",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      padding: "24px",
      fontFamily: "'Georgia', 'Times New Roman', serif",
    }}>
      {/* Browser chrome */}
      <div style={{
        width: "100%",
        maxWidth: 520,
        background: "white",
        borderRadius: 20,
        boxShadow: "0 24px 80px rgba(10,22,40,0.14), 0 4px 20px rgba(10,22,40,0.06)",
        overflow: "hidden",
      }}>
        {/* Browser bar */}
        <div style={{
          background: "#f5f7fa",
          borderBottom: "1px solid #e8eef4",
          padding: "12px 20px",
          display: "flex",
          alignItems: "center",
          gap: 12,
        }}>
          <div style={{ display: "flex", gap: 6 }}>
            {["#ff5f57", "#febc2e", "#28c840"].map((c, i) => (
              <div key={i} style={{ width: 12, height: 12, borderRadius: "50%", background: c }} />
            ))}
          </div>
          <div style={{
            flex: 1,
            background: "white",
            border: "1px solid #e0e8f0",
            borderRadius: 6,
            padding: "5px 14px",
            fontSize: 12,
            color: "#8aa0b8",
            fontFamily: "monospace",
          }}>
            app.ové.io/start
          </div>
        </div>

        {/* App content */}
        <div style={{ padding: "40px 44px 44px" }}>

          {/* Logo */}
          <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 36 }}>
            <div style={{
              width: 32, height: 32, borderRadius: "50%",
              border: "1.5px solid #3b82f6",
              display: "flex", alignItems: "center", justifyContent: "center",
            }}>
              <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                <path d="M3 7 L7 3 L11 7" stroke="#3b82f6" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M7 3 L7 11" stroke="#3b82f6" strokeWidth="2" strokeLinecap="round"/>
              </svg>
            </div>
            <span style={{ fontSize: 22, fontWeight: 400, letterSpacing: "-0.03em", color: "#0a1628" }}>Ové</span>
          </div>

          {/* Step 0: Welcome */}
          {step === 0 && (
            <Screen>
              <div style={{ marginBottom: 36 }}>
                <h1 style={{ margin: "0 0 14px", fontSize: "clamp(26px, 5vw, 36px)", fontWeight: 400, letterSpacing: "-0.03em", color: "#0a1628", lineHeight: 1.2 }}>
                  From someday<br />to today.
                </h1>
                <p style={{ margin: 0, fontSize: 15, color: "#6b8aaa", lineHeight: 1.75 }}>
                  Start investing in under 2 minutes.<br />No jargon. No minimums. Just your first step.
                </p>
              </div>
              <div style={{ display: "flex", gap: 24, marginBottom: 36 }}>
                {[{ icon: "⚡", label: "2 min setup" }, { icon: "€", label: "Start with €1" }, { icon: "✦", label: "No experience needed" }].map((f, i) => (
                  <div key={i} style={{ textAlign: "center", flex: 1 }}>
                    <div style={{ fontSize: 20, marginBottom: 6 }}>{f.icon}</div>
                    <div style={{ fontSize: 11, color: "#8aa0b8", lineHeight: 1.4 }}>{f.label}</div>
                  </div>
                ))}
              </div>
              <Button onClick={next}>Get started →</Button>
              <div style={{ textAlign: "center", marginTop: 16, fontSize: 12, color: "#8aa0b8" }}>
                Already have an account? <span style={{ color: "#3b82f6", cursor: "pointer" }}>Sign in</span>
              </div>
            </Screen>
          )}

          {/* Step 1: Name */}
          {step === 1 && (
            <Screen title="What should we call you?" subtitle="Just your first name is fine.">
              <ProgressBar current={1} total={totalSteps} />
              <input
                type="text"
                placeholder="Your first name"
                value={data.name}
                onChange={e => set("name", e.target.value)}
                autoFocus
                style={{
                  width: "100%",
                  padding: "16px",
                  fontSize: 18,
                  border: "2px solid",
                  borderColor: data.name ? "#3b82f6" : "#e0e8f0",
                  borderRadius: 12,
                  outline: "none",
                  fontFamily: "'Georgia', serif",
                  color: "#0a1628",
                  boxSizing: "border-box",
                  transition: "border-color 0.2s",
                  marginBottom: 8,
                }}
              />
              <Button onClick={next} disabled={!data.name.trim()}>Continue →</Button>
            </Screen>
          )}

          {/* Step 2: Goal */}
          {step === 2 && (
            <Screen
              title={`Hi ${data.name} 👋`}
              subtitle="What's your main reason for investing? We'll personalise your experience."
            >
              <ProgressBar current={2} total={totalSteps} />
              <div style={{ display: "flex", flexDirection: "column", gap: 10, marginBottom: 8 }}>
                {goals.map(g => (
                  <div
                    key={g.id}
                    onClick={() => { set("goal", g.id); }}
                    style={{
                      padding: "16px 20px",
                      border: `2px solid ${data.goal === g.id ? "#3b82f6" : "#e0e8f0"}`,
                      borderRadius: 12,
                      cursor: "pointer",
                      display: "flex",
                      alignItems: "center",
                      gap: 16,
                      background: data.goal === g.id ? "#f0f7ff" : "white",
                      transition: "all 0.15s ease",
                    }}
                  >
                    <span style={{ fontSize: 22 }}>{g.icon}</span>
                    <span style={{ fontSize: 15, color: "#0a1628" }}>{g.label}</span>
                    {data.goal === g.id && <span style={{ marginLeft: "auto", color: "#3b82f6", fontSize: 18 }}>✓</span>}
                  </div>
                ))}
              </div>
              <Button onClick={next} disabled={!data.goal}>Continue →</Button>
            </Screen>
          )}

          {/* Step 3: Amount */}
          {step === 3 && (
            <Screen
              title="How much to start with?"
              subtitle="You can always add more later. There's no wrong answer here."
            >
              <ProgressBar current={3} total={totalSteps} />
              <div style={{
                textAlign: "center",
                padding: "28px 0 24px",
              }}>
                <div style={{ fontSize: 56, fontWeight: 400, letterSpacing: "-0.04em", color: "#0a1628", marginBottom: 4 }}>
                  €{data.amount}
                </div>
                <div style={{ fontSize: 13, color: "#8aa0b8" }}>your first investment</div>
              </div>
              <input
                type="range"
                min={1} max={500} step={1}
                value={data.amount}
                onChange={e => set("amount", Number(e.target.value))}
                style={{ width: "100%", marginBottom: 16, accentColor: "#3b82f6" }}
              />
              <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12, color: "#8aa0b8", marginBottom: 24 }}>
                <span>€1</span><span>€500</span>
              </div>
              <div style={{ display: "flex", gap: 8, marginBottom: 8 }}>
                {[5, 10, 25, 50, 100].map(amt => (
                  <button key={amt} onClick={() => set("amount", amt)} style={{
                    flex: 1,
                    padding: "8px 0",
                    border: `1px solid ${data.amount === amt ? "#3b82f6" : "#e0e8f0"}`,
                    borderRadius: 8,
                    background: data.amount === amt ? "#f0f7ff" : "white",
                    color: data.amount === amt ? "#3b82f6" : "#6b8aaa",
                    fontSize: 13,
                    cursor: "pointer",
                    fontFamily: "'Georgia', serif",
                  }}>
                    €{amt}
                  </button>
                ))}
              </div>
              <Button onClick={next}>Continue →</Button>
            </Screen>
          )}

          {/* Step 4: Portfolio */}
          {step === 4 && (
            <Screen title="Choose your style" subtitle="Don't overthink it. You can change this anytime.">
              <ProgressBar current={4} total={totalSteps} />
              <div style={{ display: "flex", flexDirection: "column", gap: 10, marginBottom: 8 }}>
                {portfolios.map(p => (
                  <div
                    key={p.id}
                    onClick={() => set("portfolio", p.id)}
                    style={{
                      padding: "18px 20px",
                      border: `2px solid ${data.portfolio === p.id ? p.color : "#e0e8f0"}`,
                      borderRadius: 12,
                      cursor: "pointer",
                      background: data.portfolio === p.id ? "#f8faff" : "white",
                      transition: "all 0.15s ease",
                    }}
                  >
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                        <span style={{ fontSize: 18, color: p.color }}>{p.icon}</span>
                        <span style={{ fontSize: 15, color: "#0a1628" }}>{p.name}</span>
                        <span style={{
                          fontSize: 10, fontFamily: "monospace",
                          background: p.color + "15", color: p.color,
                          border: `1px solid ${p.color}30`,
                          borderRadius: 20, padding: "2px 8px",
                          letterSpacing: "0.05em",
                        }}>{p.risk}</span>
                      </div>
                      <span style={{ fontSize: 13, color: "#3b82f6", fontStyle: "italic" }}>{p.return}</span>
                    </div>
                    <div style={{ fontSize: 12, color: "#8aa0b8", lineHeight: 1.5 }}>{p.description}</div>
                    {data.portfolio === p.id && (
                      <div style={{ display: "flex", gap: 4, marginTop: 12, height: 4, borderRadius: 2, overflow: "hidden" }}>
                        {p.split.map((s, i) => (
                          <div key={i} style={{
                            flex: s.pct,
                            background: [p.color, p.color + "80", p.color + "40"][i],
                            borderRadius: 2,
                          }} title={`${s.label} ${s.pct}%`} />
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
              <Button onClick={next}>Continue →</Button>
            </Screen>
          )}

          {/* Step 5: Confirm */}
          {step === 5 && (
            <Screen title="Ready to start." subtitle="Here's what's about to happen.">
              <ProgressBar current={5} total={totalSteps} />
              <div style={{
                background: "#f5f8ff",
                border: "1px solid #dce8f8",
                borderRadius: 14,
                padding: "24px",
                marginBottom: 20,
              }}>
                {[
                  { label: "Name", value: data.name },
                  { label: "First investment", value: `€${data.amount}` },
                  { label: "Portfolio", value: selectedPortfolio?.name },
                  { label: "Expected return", value: selectedPortfolio?.return },
                ].map((row, i) => (
                  <div key={i} style={{
                    display: "flex", justifyContent: "space-between",
                    padding: "10px 0",
                    borderBottom: i < 3 ? "1px solid #e0ecf8" : "none",
                    fontSize: 14,
                  }}>
                    <span style={{ color: "#6b8aaa" }}>{row.label}</span>
                    <span style={{ color: "#0a1628", fontWeight: 400 }}>{row.value}</span>
                  </div>
                ))}
              </div>
              <div style={{
                background: "#f0fff4",
                border: "1px solid #bbf7d0",
                borderRadius: 10,
                padding: "14px 18px",
                fontSize: 13,
                color: "#166534",
                marginBottom: 16,
                lineHeight: 1.6,
              }}>
                💡 In 10 years at {selectedPortfolio?.return.split("–")[0].replace("~", "")}, your €{data.amount} could grow to approximately <strong>€{projectedValue(data.amount, 10, 0.08)}</strong>.
              </div>
              <Button onClick={next}>Invest €{data.amount} now →</Button>
              <div style={{ textAlign: "center", marginTop: 12, fontSize: 11, color: "#8aa0b8" }}>
                Protected up to €100,000 · Cancel anytime
              </div>
            </Screen>
          )}

          {/* Step 6: Done */}
          {step === 6 && (
            <Screen>
              <div style={{ textAlign: "center", padding: "20px 0 32px" }}>
                <div style={{
                  width: 72, height: 72,
                  background: "linear-gradient(135deg, #1a3a8f, #3b82f6)",
                  borderRadius: "50%",
                  display: "flex", alignItems: "center", justifyContent: "center",
                  margin: "0 auto 28px",
                  fontSize: 30,
                }}>
                  ✓
                </div>
                <h2 style={{ margin: "0 0 12px", fontSize: "clamp(24px, 4vw, 32px)", fontWeight: 400, letterSpacing: "-0.02em", color: "#0a1628" }}>
                  You did it, {data.name}.
                </h2>
                <p style={{ margin: "0 0 8px", fontSize: 15, color: "#6b8aaa", lineHeight: 1.7 }}>
                  €{data.amount} invested in your <strong>{selectedPortfolio?.name}</strong> portfolio.
                </p>
                <p style={{ margin: "0 0 36px", fontSize: 14, color: "#8aa0b8", fontStyle: "italic" }}>
                  The hardest step is behind you.
                </p>
                <div style={{
                  background: "#f5f8ff",
                  borderRadius: 14,
                  padding: "20px 24px",
                  marginBottom: 28,
                  textAlign: "left",
                }}>
                  <div style={{ fontSize: 12, color: "#8aa0b8", marginBottom: 14, fontFamily: "monospace", letterSpacing: "0.1em", textTransform: "uppercase" }}>Your portfolio</div>
                  {selectedPortfolio?.split.map((s, i) => (
                    <div key={i} style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 10 }}>
                      <div style={{ width: `${s.pct}%`, maxWidth: 120, height: 6, borderRadius: 3, background: [selectedPortfolio.color, selectedPortfolio.color + "80", selectedPortfolio.color + "40"][i] }} />
                      <span style={{ fontSize: 13, color: "#6b8aaa" }}>{s.label} · {s.pct}%</span>
                    </div>
                  ))}
                </div>
                <button onClick={() => { setStep(0); setData({ name: "", goal: "", amount: 10, portfolio: "balanced" }); }} style={{
                  background: "transparent", border: "none", color: "#3b82f6", fontSize: 13,
                  cursor: "pointer", fontFamily: "'Georgia', serif", textDecoration: "underline",
                }}>
                  ↺ Start over (demo)
                </button>
              </div>
            </Screen>
          )}
        </div>
      </div>
    </div>
  );
}
