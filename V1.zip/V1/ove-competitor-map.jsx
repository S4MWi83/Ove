import { useState } from "react";

const competitors = [
  {
    id: "ove",
    name: "Ové",
    simplicity: 95,
    beginnerFocus: 95,
    color: "#3b82f6",
    size: 18,
    tagline: "From someday to today.",
    description: "Built exclusively for first-time investors. 2-minute onboarding, €1 minimum, zero jargon.",
    strengths: ["Fastest onboarding", "Beginner-first design", "Emotional positioning", "€1 minimum"],
    weaknesses: ["No track record yet", "Limited features at launch", "Brand unknown"],
    threat: "us",
  },
  {
    id: "robinhood",
    name: "Robinhood",
    simplicity: 60,
    beginnerFocus: 45,
    color: "#00c805",
    size: 14,
    tagline: "Investing for everyone.",
    description: "Commission-free trading app. Popular but built around active trading, not beginners.",
    strengths: ["Brand recognition", "Commission-free", "Large user base", "Options & crypto"],
    weaknesses: ["Gamified UI encourages bad habits", "Not truly beginner-friendly", "Reputation issues", "US-focused"],
    threat: "indirect",
  },
  {
    id: "acorns",
    name: "Acorns",
    simplicity: 78,
    beginnerFocus: 72,
    color: "#4caf50",
    size: 12,
    tagline: "Invest the change.",
    description: "Round-up micro-investing app. Passive and automatic, but limited control and US-focused.",
    strengths: ["Fully automated", "Round-up mechanic", "Beginner-friendly", "Low friction"],
    weaknesses: ["Monthly fee eats small portfolios", "Very limited control", "US only", "No education layer"],
    threat: "closest",
  },
  {
    id: "revolut",
    name: "Revolut",
    simplicity: 55,
    beginnerFocus: 40,
    color: "#191c1f",
    size: 16,
    tagline: "All things money.",
    description: "Super-app with investing as one of many features. Overwhelming for beginners.",
    strengths: ["Huge user base", "All-in-one platform", "European presence", "Trusted brand"],
    weaknesses: ["Investing buried in features", "Not beginner-focused", "Overwhelming UI", "Jack of all trades"],
    threat: "indirect",
  },
  {
    id: "trading212",
    name: "Trading 212",
    simplicity: 48,
    beginnerFocus: 38,
    color: "#e91e63",
    size: 11,
    tagline: "Invest & trade.",
    description: "Popular European trading platform. Feature-rich but intimidating for first-timers.",
    strengths: ["Commission-free", "European focused", "Strong in UK/EU", "Fractional shares"],
    weaknesses: ["Complex interface", "Built for traders", "Overwhelming for beginners", "Jargon-heavy"],
    threat: "indirect",
  },
  {
    id: "etoro",
    name: "eToro",
    simplicity: 52,
    beginnerFocus: 50,
    color: "#0ecb81",
    size: 13,
    tagline: "The social investment network.",
    description: "Social trading platform. Copy-trading feature appealing but complexity remains high.",
    strengths: ["Social/copy trading", "Global brand", "Broad asset range", "European regulated"],
    weaknesses: ["Withdrawal fees", "Social pressure dynamic", "Not truly simple", "Complex fee structure"],
    threat: "indirect",
  },
  {
    id: "inertia",
    name: "Doing nothing",
    simplicity: 100,
    beginnerFocus: 0,
    color: "#94a3b8",
    size: 20,
    tagline: "I'll start tomorrow.",
    description: "The real competitor. 70% of people who want to invest never start. This is what Ové is truly fighting.",
    strengths: ["Zero effort", "No risk of loss", "Familiar", "Always available"],
    weaknesses: ["Money loses value to inflation", "Miss compounding growth", "Regret later", "No financial future"],
    threat: "real",
  },
];

const threatLabels = {
  us: { label: "That's us", color: "#3b82f6" },
  closest: { label: "Closest rival", color: "#f59e0b" },
  indirect: { label: "Indirect rival", color: "#6b7280" },
  real: { label: "Real competitor", color: "#ef4444" },
};

export default function CompetitorMap() {
  const [selected, setSelected] = useState("ove");
  const [view, setView] = useState("map"); // map | table

  const selectedComp = competitors.find(c => c.id === selected);

  // Map the 0-100 scores to percentage positions on the chart
  const toX = (v) => `${v}%`;
  const toY = (v) => `${100 - v}%`;

  return (
    <div style={{
      minHeight: "100vh",
      background: "#f8f9fb",
      fontFamily: "'Georgia', 'Times New Roman', serif",
      color: "#0a1628",
    }}>
      {/* Header */}
      <div style={{
        background: "linear-gradient(135deg, #0a1628 0%, #0d2444 100%)",
        padding: "40px 44px 36px",
        color: "white",
      }}>
        <div style={{ maxWidth: 1000, margin: "0 auto" }}>
          <div style={{ fontSize: 11, fontFamily: "monospace", letterSpacing: "0.25em", color: "#3b82f6", textTransform: "uppercase", marginBottom: 10 }}>
            Ové · Competitive Landscape
          </div>
          <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between", flexWrap: "wrap", gap: 16 }}>
            <h1 style={{ margin: 0, fontSize: "clamp(22px, 4vw, 32px)", fontWeight: 400, letterSpacing: "-0.02em" }}>
              Where Ové Wins
            </h1>
            <div style={{ display: "flex", gap: 8 }}>
              {["map", "table"].map(v => (
                <button key={v} onClick={() => setView(v)} style={{
                  background: view === v ? "#3b82f620" : "transparent",
                  border: `1px solid ${view === v ? "#3b82f6" : "#ffffff20"}`,
                  borderRadius: 20,
                  padding: "7px 18px",
                  fontSize: 11,
                  color: view === v ? "#3b82f6" : "#8aa0b8",
                  cursor: "pointer",
                  fontFamily: "monospace",
                  letterSpacing: "0.1em",
                  textTransform: "uppercase",
                }}>
                  {v === "map" ? "⊹ Matrix" : "≡ Breakdown"}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div style={{ maxWidth: 1000, margin: "0 auto", padding: "40px 44px 80px" }}>

        {view === "map" && (
          <div style={{ display: "grid", gridTemplateColumns: "1fr 320px", gap: 28, alignItems: "start" }}>

            {/* Matrix */}
            <div>
              <div style={{
                background: "white",
                borderRadius: 16,
                border: "1px solid #e0e8f0",
                padding: "32px",
                boxShadow: "0 4px 24px rgba(10,22,40,0.06)",
                position: "relative",
              }}>
                {/* Axis labels */}
                <div style={{ position: "absolute", top: 16, left: "50%", transform: "translateX(-50%)", fontSize: 11, color: "#8aa0b8", fontFamily: "monospace", letterSpacing: "0.1em", textTransform: "uppercase" }}>
                  Beginner Focus →
                </div>
                <div style={{
                  position: "absolute", left: 12, top: "50%",
                  transform: "translateY(-50%) rotate(-90deg)",
                  fontSize: 11, color: "#8aa0b8", fontFamily: "monospace", letterSpacing: "0.1em", textTransform: "uppercase",
                  whiteSpace: "nowrap",
                }}>
                  ← Simplicity
                </div>

                {/* Grid */}
                <div style={{
                  position: "relative",
                  width: "100%",
                  paddingBottom: "85%",
                  marginTop: 20,
                  marginLeft: 20,
                }}>
                  <div style={{ position: "absolute", inset: 0 }}>
                    {/* Quadrant lines */}
                    <div style={{ position: "absolute", left: "50%", top: 0, bottom: 0, width: 1, background: "#e8eef4" }} />
                    <div style={{ position: "absolute", top: "50%", left: 0, right: 0, height: 1, background: "#e8eef4" }} />

                    {/* Ové's sweet spot highlight */}
                    <div style={{
                      position: "absolute",
                      right: 0, top: 0,
                      width: "50%", height: "50%",
                      background: "linear-gradient(135deg, #3b82f608, #3b82f615)",
                      border: "1px dashed #3b82f630",
                      borderRadius: "0 12px 0 0",
                    }}>
                      <div style={{ position: "absolute", top: 8, right: 10, fontSize: 10, color: "#3b82f680", fontFamily: "monospace", letterSpacing: "0.1em" }}>
                        OVÉ'S ZONE
                      </div>
                    </div>

                    {/* Quadrant labels */}
                    {[
                      { label: "Complex + Niche", x: "8%", y: "8%", align: "left" },
                      { label: "Simple + Niche", x: "8%", y: "54%", align: "left" },
                      { label: "Complex + Mainstream", x: "54%", y: "8%", align: "left" },
                    ].map((q, i) => (
                      <div key={i} style={{
                        position: "absolute", left: q.x, top: q.y,
                        fontSize: 10, color: "#c8d8e8", fontFamily: "monospace",
                        letterSpacing: "0.05em", textTransform: "uppercase",
                      }}>
                        {q.label}
                      </div>
                    ))}

                    {/* Competitor dots */}
                    {competitors.map(c => (
                      <div
                        key={c.id}
                        onClick={() => setSelected(c.id)}
                        title={c.name}
                        style={{
                          position: "absolute",
                          left: `calc(${toX(c.beginnerFocus)} - ${c.size}px)`,
                          top: `calc(${toY(c.simplicity)} - ${c.size}px)`,
                          width: c.size * 2,
                          height: c.size * 2,
                          borderRadius: "50%",
                          background: c.color,
                          opacity: selected === c.id ? 1 : 0.7,
                          cursor: "pointer",
                          border: selected === c.id ? `3px solid ${c.color}` : "3px solid white",
                          boxShadow: selected === c.id
                            ? `0 0 0 4px ${c.color}40, 0 4px 16px ${c.color}40`
                            : "0 2px 8px rgba(10,22,40,0.15)",
                          transition: "all 0.2s ease",
                          zIndex: selected === c.id ? 10 : 1,
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                        }}
                      >
                        {c.id === "ove" && (
                          <span style={{ fontSize: 10, color: "white", fontFamily: "Georgia", fontWeight: 400 }}>Ó</span>
                        )}
                      </div>
                    ))}

                    {/* Labels for dots */}
                    {competitors.map(c => (
                      <div
                        key={c.id + "-label"}
                        style={{
                          position: "absolute",
                          left: `calc(${toX(c.beginnerFocus)} + ${c.size + 4}px)`,
                          top: `calc(${toY(c.simplicity)} - 8px)`,
                          fontSize: c.id === "ove" ? 13 : 11,
                          fontWeight: c.id === "ove" ? 400 : 400,
                          color: c.id === "ove" ? "#0a1628" : "#6b8aaa",
                          whiteSpace: "nowrap",
                          pointerEvents: "none",
                          fontFamily: c.id === "ove" ? "Georgia" : "monospace",
                        }}
                      >
                        {c.name}
                      </div>
                    ))}
                  </div>
                </div>

                {/* Axis bottom labels */}
                <div style={{ display: "flex", justifyContent: "space-between", marginTop: 8, marginLeft: 20, fontSize: 11, color: "#c8d8e8", fontFamily: "monospace" }}>
                  <span>Trader-focused</span>
                  <span>Beginner-focused</span>
                </div>
              </div>

              {/* Legend */}
              <div style={{ display: "flex", gap: 16, marginTop: 16, flexWrap: "wrap" }}>
                {Object.entries(threatLabels).map(([key, val]) => (
                  <div key={key} style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 12, color: "#6b8aaa" }}>
                    <div style={{ width: 8, height: 8, borderRadius: "50%", background: val.color }} />
                    {val.label}
                  </div>
                ))}
              </div>
            </div>

            {/* Detail panel */}
            {selectedComp && (
              <div style={{
                background: "white",
                borderRadius: 16,
                border: `1px solid ${selectedComp.color}30`,
                boxShadow: `0 4px 24px ${selectedComp.color}15`,
                overflow: "hidden",
                position: "sticky",
                top: 20,
              }}>
                <div style={{
                  background: selectedComp.id === "inertia" ? "#f1f5f9" : selectedComp.color,
                  padding: "24px 24px 20px",
                }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10 }}>
                    <div style={{ fontSize: 22, fontWeight: 400, letterSpacing: "-0.02em", color: selectedComp.id === "inertia" ? "#64748b" : "white" }}>
                      {selectedComp.name}
                    </div>
                    <div style={{
                      fontSize: 10, fontFamily: "monospace", letterSpacing: "0.1em",
                      background: "rgba(255,255,255,0.2)",
                      color: selectedComp.id === "inertia" ? "#64748b" : "white",
                      padding: "3px 10px", borderRadius: 20,
                      textTransform: "uppercase",
                    }}>
                      {threatLabels[selectedComp.threat].label}
                    </div>
                  </div>
                  <div style={{ fontSize: 13, color: selectedComp.id === "inertia" ? "#94a3b8" : "rgba(255,255,255,0.8)", fontStyle: "italic" }}>
                    "{selectedComp.tagline}"
                  </div>
                </div>

                <div style={{ padding: "20px 24px" }}>
                  <p style={{ margin: "0 0 20px", fontSize: 13, color: "#6b8aaa", lineHeight: 1.7 }}>
                    {selectedComp.description}
                  </p>

                  {/* Scores */}
                  <div style={{ marginBottom: 20 }}>
                    {[
                      { label: "Simplicity", value: selectedComp.simplicity },
                      { label: "Beginner Focus", value: selectedComp.beginnerFocus },
                    ].map((s, i) => (
                      <div key={i} style={{ marginBottom: 10 }}>
                        <div style={{ display: "flex", justifyContent: "space-between", fontSize: 11, color: "#8aa0b8", marginBottom: 5, fontFamily: "monospace" }}>
                          <span>{s.label.toUpperCase()}</span><span>{s.value}/100</span>
                        </div>
                        <div style={{ height: 4, background: "#f0f4f8", borderRadius: 2 }}>
                          <div style={{
                            width: `${s.value}%`, height: "100%",
                            background: selectedComp.color,
                            borderRadius: 2,
                            transition: "width 0.5s ease",
                          }} />
                        </div>
                      </div>
                    ))}
                  </div>

                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
                    <div>
                      <div style={{ fontSize: 10, fontFamily: "monospace", color: "#4ade80", letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 8 }}>Strengths</div>
                      {selectedComp.strengths.map((s, i) => (
                        <div key={i} style={{ fontSize: 12, color: "#374151", marginBottom: 4, paddingLeft: 12, position: "relative" }}>
                          <span style={{ position: "absolute", left: 0, color: "#4ade80" }}>+</span>{s}
                        </div>
                      ))}
                    </div>
                    <div>
                      <div style={{ fontSize: 10, fontFamily: "monospace", color: "#f87171", letterSpacing: "0.1em", textTransform: "uppercase", marginBottom: 8 }}>Weaknesses</div>
                      {selectedComp.weaknesses.map((w, i) => (
                        <div key={i} style={{ fontSize: 12, color: "#374151", marginBottom: 4, paddingLeft: 12, position: "relative" }}>
                          <span style={{ position: "absolute", left: 0, color: "#f87171" }}>−</span>{w}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {view === "table" && (
          <div style={{ overflowX: "auto" }}>
            <table style={{ width: "100%", borderCollapse: "collapse", background: "white", borderRadius: 16, overflow: "hidden", boxShadow: "0 4px 24px rgba(10,22,40,0.06)", border: "1px solid #e0e8f0" }}>
              <thead>
                <tr style={{ background: "#0a1628", color: "white" }}>
                  {["", "Simplicity", "Beginner Focus", "Min. Investment", "Europe", "Onboarding", "Threat Level"].map((h, i) => (
                    <th key={i} style={{ padding: "14px 18px", textAlign: i === 0 ? "left" : "center", fontSize: 11, fontFamily: "monospace", letterSpacing: "0.1em", textTransform: "uppercase", fontWeight: 400, color: "#93b4d4" }}>
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {[
                  { name: "Ové", color: "#3b82f6", simplicity: "★★★★★", beginner: "★★★★★", min: "€1", europe: "✓", onboarding: "2 min", threat: "us" },
                  { name: "Acorns", color: "#4caf50", simplicity: "★★★★☆", beginner: "★★★★☆", min: "$5", europe: "✗", onboarding: "5 min", threat: "closest" },
                  { name: "Revolut", color: "#191c1f", simplicity: "★★★☆☆", beginner: "★★☆☆☆", min: "€1", europe: "✓", onboarding: "10+ min", threat: "indirect" },
                  { name: "eToro", color: "#0ecb81", simplicity: "★★★☆☆", beginner: "★★★☆☆", min: "$50", europe: "✓", onboarding: "15 min", threat: "indirect" },
                  { name: "Trading 212", color: "#e91e63", simplicity: "★★☆☆☆", beginner: "★★☆☆☆", min: "€1", europe: "✓", onboarding: "20 min", threat: "indirect" },
                  { name: "Robinhood", color: "#00c805", simplicity: "★★★☆☆", beginner: "★★☆☆☆", min: "$1", europe: "✗", onboarding: "10 min", threat: "indirect" },
                  { name: "Doing nothing", color: "#94a3b8", simplicity: "★★★★★", beginner: "—", min: "—", europe: "—", onboarding: "0 sec", threat: "real" },
                ].map((row, i) => (
                  <tr key={i} style={{
                    borderBottom: "1px solid #f0f4f8",
                    background: row.name === "Ové" ? "#f0f7ff" : i % 2 === 0 ? "white" : "#fafbfc",
                  }}>
                    <td style={{ padding: "14px 18px", display: "flex", alignItems: "center", gap: 10 }}>
                      <div style={{ width: 10, height: 10, borderRadius: "50%", background: row.color, flexShrink: 0 }} />
                      <span style={{ fontSize: 14, color: "#0a1628", fontWeight: row.name === "Ové" ? 400 : 400 }}>{row.name}</span>
                    </td>
                    {[row.simplicity, row.beginner, row.min, row.europe, row.onboarding].map((val, j) => (
                      <td key={j} style={{ padding: "14px 18px", textAlign: "center", fontSize: 13, color: "#374151" }}>{val}</td>
                    ))}
                    <td style={{ padding: "14px 18px", textAlign: "center" }}>
                      <span style={{
                        fontSize: 10, fontFamily: "monospace",
                        color: threatLabels[row.threat].color,
                        background: threatLabels[row.threat].color + "15",
                        border: `1px solid ${threatLabels[row.threat].color}30`,
                        padding: "3px 10px", borderRadius: 20,
                        letterSpacing: "0.05em", textTransform: "uppercase",
                        whiteSpace: "nowrap",
                      }}>
                        {threatLabels[row.threat].label}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {/* Key insight */}
        <div style={{
          marginTop: 28,
          background: "linear-gradient(135deg, #0a1628, #0d2444)",
          borderRadius: 14,
          padding: "28px 32px",
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))",
          gap: 24,
        }}>
          <div>
            <div style={{ fontSize: 11, fontFamily: "monospace", color: "#3b82f6", letterSpacing: "0.15em", textTransform: "uppercase", marginBottom: 8 }}>The Gap</div>
            <div style={{ fontSize: 14, color: "#93b4d4", lineHeight: 1.7 }}>No European app is truly built for the first-time investor. Everyone's chasing traders.</div>
          </div>
          <div>
            <div style={{ fontSize: 11, fontFamily: "monospace", color: "#3b82f6", letterSpacing: "0.15em", textTransform: "uppercase", marginBottom: 8 }}>The Real Rival</div>
            <div style={{ fontSize: 14, color: "#93b4d4", lineHeight: 1.7 }}>70% of would-be investors never start. Ové isn't fighting Revolut — it's fighting inertia.</div>
          </div>
          <div>
            <div style={{ fontSize: 11, fontFamily: "monospace", color: "#3b82f6", letterSpacing: "0.15em", textTransform: "uppercase", marginBottom: 8 }}>Ové's Moat</div>
            <div style={{ fontSize: 14, color: "#93b4d4", lineHeight: 1.7 }}>Owning "first step" emotionally is defensible. Once someone starts with Ové, they stay.</div>
          </div>
        </div>
      </div>
    </div>
  );
}
