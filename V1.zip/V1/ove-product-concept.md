# Ové — Product Concept Document
*Last updated: March 2026*

---

## Core Idea
An investing app that gets a complete beginner started in minutes, from €10, with zero jargon. Built for Europeans who keep saying "I'll start next month" but never do.

**Tagline:** From someday to today.

---

## The Problem
Only 9% of Europeans own stock directly (ECB). That means 320 million people — 91% — have never invested a single euro. The barrier isn't money or knowledge — it's friction and complexity. A 2026 ESMA report confirms this: multiple regulatory and non-regulatory factors combine to stop people before they even start.

Every existing app was built for people who already know what they're doing. They overwhelm beginners with hundreds of options before they've invested a single euro.

---

## The Core Mission
Most Europeans keep their savings in a bank account where inflation quietly eats away at it year after year. Ové is a simple way to put that money to work instead. You don't need to know anything about stocks or finance — you just pick how much risk you're comfortable with, deposit what you can afford, and Ové invests it for you automatically. No complicated decisions, no jargon, no switching banks. Just a straightforward way to finally start.

---

## The Solution
Three steps. Then you're investing.

1. **Sign up** — smooth, fast, nothing like opening a bank account
2. **Pick a risk level** — Steady, Balanced, or Growth. Three options, not three hundred.
3. **You're invested** — Ové handles everything else automatically

Ové removes every unnecessary choice from the onboarding experience. Regulatory compliance is handled invisibly so the user never has to think about it.

---

## Product Type
Web app (browser-based, mobile responsive). No app store required to start.

---

## Onboarding Flow (7 screens)

1. **Welcome** — Brand promise, 3 key stats
2. **Name** — First name only
3. **Goal** — 4 options: Emergency fund / Future / Retirement / Grow money
4. **Amount** — Slider + quick-pick, starts €10, minimum €100
5. **Portfolio** — 3 options (see below)
6. **Confirm** — Summary + 10-year projection
7. **Done** — Celebration screen

---

## Core Portfolios (3 options)

| Name | Risk | Allocation | Est. Return |
|------|------|------------|-------------|
| Steady | Low | 70% Bonds, 20% Stocks, 10% Cash | ~4–6%/yr |
| Balanced | Medium | 60% Stocks, 30% Bonds, 10% Cash | ~7–9%/yr |
| Growth | Higher | 90% Stocks, 8% Bonds, 2% Cash | ~10–12%/yr |

Users never pick individual stocks or ETFs. Ové handles allocation automatically based on their choice.

---

## User Journey & Tiers

### Beginner Ové (Month 0)
- Sign up in under 2 minutes
- Pick Steady, Balanced or Growth
- Invest from €10
- No stock picking, no complexity
- Zero decisions after setup

### Experienced Ové (Month 6+)
- After 6 consecutive months of investing, users unlock **Experienced Ové**
- Triggered by a milestone notification:
  *"6 months ago you took your first step. Look at you now. Ready to take the wheel?"*
- Users can **choose** to unlock the Experienced feature — it's optional, not forced
- Experienced users keep their core portfolio AND can add individual stocks/ETFs alongside it
- Full control for those who want it, without overwhelming those who don't

**Why 6 months:**
- Users have built a genuine investing habit
- They're confident enough to make their own decisions
- They're emotionally invested in the product — less likely to churn
- Natural upsell moment

---

## Portfolio Transparency

From day one users can see exactly what their money is invested in — but presented in plain English, never raw financial data.

**What a beginner sees in their dashboard:**

> **Your Growth portfolio contains:**
> - 🌍 Global Stocks — 90% — *Top companies worldwide like Apple, Microsoft, Amazon*
> - 📊 Bonds — 8% — *Government and corporate bonds for stability*
> - 💵 Cash — 2% — *Always accessible*

**If they tap into Global Stocks they see:**
> *Your money is spread across 1,500+ companies in 23 countries. No single company makes up more than 4% of your portfolio.*

**Design principle:**
- Plain English first, financial jargon never
- Let users dig deeper if they want — never force it
- Ticker symbols and percentages are hidden by default
- Gradually educates users about investing through their own portfolio
- Builds confidence — "I own a tiny piece of Apple" is exciting
- Naturally leads users toward Experienced Ové after 6 months

---

## Regulatory Compliance as a Core Feature
Regulatory complexity is one of the biggest barriers to investing in Europe (ESMA 2026). Ové absorbs this complexity entirely on behalf of the user. MiFID II compliance, KYC, AML — all handled invisibly. The user never sees a form they don't understand. Compliance is not a checkbox at Ové — it's a core product principle that builds trust.

---

## Business Model

- **0.5% AUM fee** — scales naturally with user portfolio size. At 100,000 users with €1,500 average portfolio = €150M AUM = €750,000/year revenue
- **Referral/partner revenue** from regulated broker infrastructure

---

## Technical Infrastructure

- **Frontend:** Next.js, Tailwind CSS
- **Backend:** Supabase (auth + database)
- **Deployment:** Vercel
- **Broker partner:** Saxo OpenAPI, DriveWealth or Scalable Capital (white-label)
- **KYC:** Onfido or Veriff
- **Payments:** Treezor or Swan
- **Regulatory:** MiFID II via broker partner licence

---

## Key Differentiators

1. Sign-up ease — nothing like opening a bank account
2. 3 portfolios, not 300 — zero overwhelm
3. No bank switching required
4. Regulatory compliance handled invisibly
5. Grows with the user — Beginner → Experienced journey
6. Built for the 91%, not the 9%

---

## What Ové is NOT
- Not a trading platform
- Not a bank
- Not built for experts
- Not trying to compete with Trading 212 or eToro on features

---

## Competitive Landscape

| App | Simplicity | Beginner Focus | Europe | Verdict |
|-----|------------|----------------|--------|---------|
| Trading 212 | Medium | Low | ✅ | Too complex |
| eToro | Low | Low | ✅ | Built for traders |
| Revolut | Medium | Low | ✅ | Finance super-app, not focused |
| Bitpanda | Medium | Low-Medium | ✅ | Biggest inspiration — clean UX, regulatory compliance, fast onboarding — but still 3,000+ choices, focused on the 9% |
| Robinhood EU | Low | Low | ⚠️ Partial | Tokenized stocks only, not real shares, not beginner focused |
| Acorns | High | High | ❌ US only | Closest concept — micro-investing, simple — wrong continent |
| **Ové** | **Very High** | **Very High** | ✅ | **Unoccupied position** |

### Bitpanda — Inspiration & Differentiation
Bitpanda (founded 2014) is the closest European reference point:
- **Taken from Bitpanda:** regulatory compliance, clean UX, "get started in minutes" in practice
- **Different from Bitpanda:** 3 choices not 3,000 — they still focus on the 9% who already know what they want

### Robinhood EU — Not a Real Threat Yet
Robinhood has expanded into Europe but only offers tokenized stocks and crypto — not real share ownership. Not covered by EU investor compensation schemes. Their DNA is active trading, not beginner investing. Even if they expand fully, they will not build for the 91%.

---

## The Market Opportunity
- 320 million Europeans haven't invested yet
- Average liquid savings of a non-investor: €10,000–30,000
- Realistic starting portfolio with Ové: €1,000–1,500
- At 100,000 users: €150M AUM → €750,000/year from 0.5% fee alone
- Path to profitability: ~€5M AUM (~3,300 users at €1,500 average)

---

## Validation
- **ECB data:** Only 9% of Europeans own stock directly
- **ESMA March 2026 report:** Confirms friction, jargon, complexity and lack of trust as primary barriers — exactly what Ové is built to solve
- **US comparison:** 21% of Americans own stock directly (Federal Reserve SCF) — the gap is real and driven by product, not culture

---

## The Robinhood Parallel
Robinhood proved zero friction gets people investing — 20 million users. But it drifted into complexity and gamification. Europe never got that first simple moment. Ové is that moment for Europe — without the complexity drift.

---

## Vision
Every European who wants to invest but hasn't started yet — that's our user. Not the trader. Not the expert. The person who keeps saying someday. We turn someday into today.
