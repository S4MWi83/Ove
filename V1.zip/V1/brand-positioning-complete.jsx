const sections = [
  {
    number: "01",
    title: "The Problem You Solve",
    answer: "Most people never start investing — not because they don't want to, but because the complexity, the fear of loss, and the sheer number of steps make it easier to just do nothing.",
    tag: "Core Pain",
  },
  {
    number: "02",
    title: "Your Target Person",
    answer: "25–34 year olds earning a real income for the first time, but somehow still broke at the end of the month. They scroll past investing content on TikTok and think 'I should do that' — then close the app and forget about it.",
    tag: "Audience",
  },
  {
    number: "03",
    title: "Your Unique Insight",
    answer: "The biggest barrier to investing isn't knowledge or money — it's the onboarding. If you can get someone invested in under 2 minutes, you've won. Radical simplicity is the product.",
    tag: "Strategic Insight",
  },
  {
    number: "04",
    title: "What You Offer",
    answer: "An investing app that gets you started in under 2 minutes — no confusing options, no minimum balance, no jargon. You sign up, and start investing.",
    tag: "Product",
  },
  {
    number: "05",
    title: "Why You, Not Them",
    answer: "Unlike Robinhood or Trading 212 — built for confident traders — we're designed exclusively for people who've never invested before. Fastest onboarding in the market, starting with just €1.",
    tag: "Differentiation",
  },
  {
    number: "06",
    title: "Your Brand Promise",
    answer: "From 'I'll start investing someday' to actually started — today.",
    tag: "Promise",
  },
];

const positioningStatement = "For 25–34 year olds living paycheck to paycheck who want to invest but never start, we offer the simplest investing app on the market — 2 minutes to sign up, €1 to begin. Unlike apps built for traders, we're built for beginners. Our promise: from 'someday' to started, today.";

export default function BrandPositioningComplete() {
  return (
    <div style={{
      minHeight: "100vh",
      background: "#0a0a0f",
      fontFamily: "'Georgia', 'Times New Roman', serif",
      color: "#f0ece4",
    }}>
      {/* Header */}
      <div style={{
        padding: "48px 40px 40px",
        borderBottom: "1px solid #1a1a2e",
        background: "linear-gradient(135deg, #0d0d1a 0%, #0a0a0f 100%)",
      }}>
        <div style={{ maxWidth: 860, margin: "0 auto" }}>
          <div style={{ fontSize: 11, letterSpacing: "0.3em", color: "#5a9fd4", textTransform: "uppercase", marginBottom: 10, fontFamily: "monospace" }}>
            Personal Finance · Digital Product · v1.0
          </div>
          <h1 style={{ margin: "0 0 8px", fontSize: "clamp(28px, 5vw, 42px)", fontWeight: 400, letterSpacing: "-0.02em" }}>
            Brand Positioning
          </h1>
          <p style={{ margin: 0, fontSize: 14, color: "#5a5465", letterSpacing: "0.05em" }}>
            Complete Foundation · Ready to Build On
          </p>
        </div>
      </div>

      <div style={{ maxWidth: 860, margin: "0 auto", padding: "48px 40px 80px" }}>

        {/* Positioning Statement Hero */}
        <div style={{
          background: "linear-gradient(135deg, #130f20 0%, #0f0f1f 100%)",
          border: "1px solid #a78bfa40",
          borderRadius: 16,
          padding: "40px 44px",
          marginBottom: 48,
          position: "relative",
          overflow: "hidden",
        }}>
          <div style={{
            position: "absolute", top: -40, right: -40,
            width: 200, height: 200,
            background: "radial-gradient(circle, #a78bfa15 0%, transparent 70%)",
            pointerEvents: "none",
          }} />
          <div style={{ fontSize: 11, letterSpacing: "0.25em", color: "#a78bfa", textTransform: "uppercase", marginBottom: 20, fontFamily: "monospace" }}>
            ✦ Positioning Statement
          </div>
          <p style={{
            margin: 0,
            fontSize: "clamp(16px, 2.5vw, 20px)",
            lineHeight: 1.85,
            color: "#d8d4cc",
            fontStyle: "italic",
          }}>
            "{positioningStatement}"
          </p>
        </div>

        {/* 6 Sections Grid */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(360px, 1fr))", gap: 16, marginBottom: 48 }}>
          {sections.map((s, i) => (
            <div key={i} style={{
              background: "#0e0e18",
              border: "1px solid #1e1e2e",
              borderRadius: 12,
              padding: "28px 28px 24px",
              position: "relative",
              overflow: "hidden",
            }}>
              <div style={{
                position: "absolute", top: 0, left: 0, right: 0, height: 2,
                background: i % 2 === 0
                  ? "linear-gradient(90deg, #5a9fd4, transparent)"
                  : "linear-gradient(90deg, #a78bfa, transparent)",
              }} />
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 14 }}>
                <div style={{ fontSize: 11, fontFamily: "monospace", color: "#3a3a5a", letterSpacing: "0.1em" }}>
                  {s.number}
                </div>
                <div style={{
                  fontSize: 10,
                  fontFamily: "monospace",
                  letterSpacing: "0.15em",
                  textTransform: "uppercase",
                  color: i % 2 === 0 ? "#5a9fd4" : "#a78bfa",
                  background: i % 2 === 0 ? "#5a9fd410" : "#a78bfa10",
                  border: `1px solid ${i % 2 === 0 ? "#5a9fd430" : "#a78bfa30"}`,
                  padding: "3px 10px",
                  borderRadius: 20,
                }}>
                  {s.tag}
                </div>
              </div>
              <div style={{ fontSize: 13, color: "#6a6480", marginBottom: 12, letterSpacing: "0.02em" }}>
                {s.title}
              </div>
              <p style={{ margin: 0, fontSize: 14, lineHeight: 1.8, color: "#c0bcb4" }}>
                {s.answer}
              </p>
            </div>
          ))}
        </div>

        {/* Next Steps */}
        <div style={{
          background: "#0e0e18",
          border: "1px solid #1e1e2e",
          borderRadius: 12,
          padding: "32px 36px",
        }}>
          <div style={{ fontSize: 11, letterSpacing: "0.25em", color: "#5a9fd4", textTransform: "uppercase", marginBottom: 20, fontFamily: "monospace" }}>
            ✦ What This Unlocks
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: 16 }}>
            {[
              { icon: "◈", label: "Brand Name", desc: "Name ideas rooted in simplicity & speed" },
              { icon: "◉", label: "Tagline", desc: "A one-liner that makes people stop scrolling" },
              { icon: "◎", label: "Competitor Map", desc: "Where you sit vs. Revolut, Acorns, Trading 212" },
              { icon: "◇", label: "Business Model", desc: "How you make money without betraying trust" },
            ].map((item, i) => (
              <div key={i} style={{
                padding: "18px 20px",
                background: "#07070f",
                border: "1px solid #1a1a2a",
                borderRadius: 10,
              }}>
                <div style={{ fontSize: 20, marginBottom: 8, color: "#5a9fd4" }}>{item.icon}</div>
                <div style={{ fontSize: 13, color: "#d0ccc4", marginBottom: 4 }}>{item.label}</div>
                <div style={{ fontSize: 11, color: "#4a4a5a", lineHeight: 1.6 }}>{item.desc}</div>
              </div>
            ))}
          </div>
        </div>

        <div style={{ marginTop: 32, textAlign: "center", fontSize: 11, color: "#2a2a3a", fontFamily: "monospace", letterSpacing: "0.15em" }}>
          BRAND POSITIONING · PERSONAL FINANCE · DIGITAL PRODUCT · 2026
        </div>
      </div>
    </div>
  );
}
