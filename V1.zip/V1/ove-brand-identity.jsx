export default function OveBrandIdentity() {
  return (
    <div style={{
      minHeight: "100vh",
      background: "#f5f7fa",
      fontFamily: "'Georgia', 'Times New Roman', serif",
      color: "#0a1628",
    }}>

      {/* Hero — Logo & Tagline */}
      <div style={{
        background: "linear-gradient(160deg, #0a1628 0%, #0d2444 60%, #0f3060 100%)",
        padding: "80px 40px 90px",
        textAlign: "center",
        position: "relative",
        overflow: "hidden",
      }}>
        {/* Background texture circles */}
        <div style={{ position: "absolute", top: -80, right: -80, width: 400, height: 400, borderRadius: "50%", background: "radial-gradient(circle, #1a4a8020 0%, transparent 70%)", pointerEvents: "none" }} />
        <div style={{ position: "absolute", bottom: -60, left: -60, width: 300, height: 300, borderRadius: "50%", background: "radial-gradient(circle, #3b82f615 0%, transparent 70%)", pointerEvents: "none" }} />

        {/* Logo mark */}
        <div style={{ display: "inline-flex", alignItems: "center", justifyContent: "center", marginBottom: 32 }}>
          <div style={{
            width: 64, height: 64,
            borderRadius: "50%",
            border: "2px solid #3b82f6",
            display: "flex", alignItems: "center", justifyContent: "center",
            marginRight: 18,
            background: "linear-gradient(135deg, #1a3a6620, #3b82f610)",
          }}>
            <svg width="28" height="28" viewBox="0 0 28 28" fill="none">
              <path d="M6 14 L14 6 L22 14" stroke="#3b82f6" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
              <path d="M14 6 L14 22" stroke="#3b82f6" strokeWidth="2.5" strokeLinecap="round"/>
            </svg>
          </div>
          <div style={{
            fontSize: 64,
            fontWeight: 400,
            letterSpacing: "-0.04em",
            color: "#ffffff",
            lineHeight: 1,
          }}>
            Ové
          </div>
        </div>

        <div style={{
          fontSize: 18,
          color: "#93b4d4",
          letterSpacing: "0.08em",
          fontStyle: "italic",
          marginBottom: 48,
        }}>
          "From someday to today."
        </div>

        {/* App mockup pill */}
        <div style={{
          display: "inline-flex",
          gap: 12,
          background: "#ffffff12",
          border: "1px solid #ffffff18",
          borderRadius: 40,
          padding: "12px 24px",
          fontSize: 13,
          color: "#93b4d4",
          letterSpacing: "0.05em",
        }}>
          <span>€1 to start</span>
          <span style={{ color: "#3b82f640" }}>·</span>
          <span>2 minutes</span>
          <span style={{ color: "#3b82f640" }}>·</span>
          <span>No jargon</span>
        </div>
      </div>

      <div style={{ maxWidth: 900, margin: "0 auto", padding: "56px 40px 80px" }}>

        {/* Color Palette */}
        <section style={{ marginBottom: 56 }}>
          <div style={{ fontSize: 11, fontFamily: "monospace", letterSpacing: "0.25em", color: "#6b8aaa", textTransform: "uppercase", marginBottom: 20 }}>
            Color Palette
          </div>
          <div style={{ display: "flex", gap: 16, flexWrap: "wrap" }}>
            {[
              { name: "Midnight", hex: "#0a1628", role: "Primary background", light: false },
              { name: "Navy", hex: "#0d2444", role: "Secondary background", light: false },
              { name: "Horizon", hex: "#3b82f6", role: "Accent / CTA", light: false },
              { name: "Mist", hex: "#93b4d4", role: "Subtle text", light: false },
              { name: "Cloud", hex: "#e8f0f8", role: "Light background", light: true },
              { name: "White", hex: "#ffffff", role: "Text on dark", light: true },
            ].map((c, i) => (
              <div key={i} style={{ flex: "1 1 120px" }}>
                <div style={{
                  height: 72,
                  background: c.hex,
                  borderRadius: 10,
                  marginBottom: 10,
                  border: c.hex === "#ffffff" ? "1px solid #e0e8f0" : "none",
                  boxShadow: "0 2px 12px rgba(0,0,0,0.08)",
                }} />
                <div style={{ fontSize: 13, fontWeight: 400, color: "#0a1628", marginBottom: 2 }}>{c.name}</div>
                <div style={{ fontSize: 11, color: "#6b8aaa", fontFamily: "monospace" }}>{c.hex}</div>
                <div style={{ fontSize: 11, color: "#8aa0b8", marginTop: 2 }}>{c.role}</div>
              </div>
            ))}
          </div>
        </section>

        {/* Typography */}
        <section style={{ marginBottom: 56 }}>
          <div style={{ fontSize: 11, fontFamily: "monospace", letterSpacing: "0.25em", color: "#6b8aaa", textTransform: "uppercase", marginBottom: 20 }}>
            Typography
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
            <div style={{ background: "#0a1628", borderRadius: 12, padding: "32px", color: "white" }}>
              <div style={{ fontSize: 11, color: "#6b8aaa", fontFamily: "monospace", letterSpacing: "0.15em", marginBottom: 16 }}>DISPLAY / HEADINGS</div>
              <div style={{ fontSize: 42, fontWeight: 400, letterSpacing: "-0.03em", lineHeight: 1.1, marginBottom: 12 }}>
                Ové
              </div>
              <div style={{ fontSize: 22, fontWeight: 400, letterSpacing: "-0.02em", color: "#93b4d4" }}>
                Start with one step.
              </div>
              <div style={{ fontSize: 11, color: "#3a5a7a", marginTop: 20, fontFamily: "monospace" }}>Georgia · Serif · Weight 400</div>
            </div>
            <div style={{ background: "#f5f7fa", borderRadius: 12, padding: "32px", border: "1px solid #e0e8f0" }}>
              <div style={{ fontSize: 11, color: "#6b8aaa", fontFamily: "monospace", letterSpacing: "0.15em", marginBottom: 16 }}>BODY / UI</div>
              <div style={{ fontSize: 16, lineHeight: 1.75, color: "#0a1628", marginBottom: 12, fontFamily: "system-ui, sans-serif" }}>
                Investing doesn't have to be complicated. We stripped everything away so you can start in under 2 minutes.
              </div>
              <div style={{ fontSize: 13, color: "#6b8aaa", fontFamily: "system-ui, sans-serif" }}>
                Clean sans-serif for UI clarity
              </div>
              <div style={{ fontSize: 11, color: "#8aa0b8", marginTop: 20, fontFamily: "monospace" }}>System UI · Sans-serif · Weight 400/500</div>
            </div>
          </div>
        </section>

        {/* Brand Voice */}
        <section style={{ marginBottom: 56 }}>
          <div style={{ fontSize: 11, fontFamily: "monospace", letterSpacing: "0.25em", color: "#6b8aaa", textTransform: "uppercase", marginBottom: 20 }}>
            Brand Voice
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: 14 }}>
            {[
              { trait: "Calm", desc: "Never alarmist. Never pushy. Like a trusted friend, not a salesperson.", icon: "◎" },
              { trait: "Honest", desc: "Plain language always. If we can't say it simply, we rethink it.", icon: "◈" },
              { trait: "Encouraging", desc: "Every small step is worth celebrating. Progress over perfection.", icon: "◉" },
              { trait: "Confident", desc: "We know this works. We don't need to shout about it.", icon: "◇" },
            ].map((v, i) => (
              <div key={i} style={{
                background: "white",
                border: "1px solid #e0e8f0",
                borderRadius: 12,
                padding: "24px",
                boxShadow: "0 2px 12px rgba(10,22,40,0.04)",
              }}>
                <div style={{ fontSize: 20, color: "#3b82f6", marginBottom: 12 }}>{v.icon}</div>
                <div style={{ fontSize: 15, color: "#0a1628", marginBottom: 8 }}>{v.trait}</div>
                <div style={{ fontSize: 12, color: "#6b8aaa", lineHeight: 1.7 }}>{v.desc}</div>
              </div>
            ))}
          </div>
        </section>

        {/* Sample Copy */}
        <section style={{ marginBottom: 56 }}>
          <div style={{ fontSize: 11, fontFamily: "monospace", letterSpacing: "0.25em", color: "#6b8aaa", textTransform: "uppercase", marginBottom: 20 }}>
            Brand Copy Examples
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            {[
              { context: "App onboarding headline", copy: "You don't need to know everything. You just need to start." },
              { context: "Push notification", copy: "Your €1 is working while you sleep. That's it. That's the update." },
              { context: "Empty state (no investments yet)", copy: "Nothing here yet — but that's about to change. Takes 2 minutes." },
              { context: "First investment confirmation", copy: "You did it. The hardest step is behind you. Welcome to Ové." },
              { context: "Social ad headline", copy: "The investing app for people who've been meaning to start." },
            ].map((item, i) => (
              <div key={i} style={{
                background: "white",
                border: "1px solid #e0e8f0",
                borderRadius: 10,
                padding: "20px 24px",
                display: "grid",
                gridTemplateColumns: "180px 1fr",
                gap: 20,
                alignItems: "center",
                boxShadow: "0 1px 8px rgba(10,22,40,0.04)",
              }}>
                <div style={{ fontSize: 11, color: "#8aa0b8", fontFamily: "monospace", letterSpacing: "0.05em" }}>{item.context}</div>
                <div style={{ fontSize: 15, color: "#0a1628", fontStyle: "italic", lineHeight: 1.6 }}>"{item.copy}"</div>
              </div>
            ))}
          </div>
        </section>

        {/* Tagline lockup */}
        <section>
          <div style={{
            background: "linear-gradient(135deg, #0a1628 0%, #0d2444 100%)",
            borderRadius: 16,
            padding: "56px 48px",
            textAlign: "center",
            position: "relative",
            overflow: "hidden",
          }}>
            <div style={{
              position: "absolute", top: "50%", left: "50%",
              transform: "translate(-50%, -50%)",
              width: 400, height: 400,
              borderRadius: "50%",
              background: "radial-gradient(circle, #3b82f608 0%, transparent 70%)",
              pointerEvents: "none",
            }} />
            <div style={{ fontSize: 13, color: "#3b82f6", fontFamily: "monospace", letterSpacing: "0.2em", textTransform: "uppercase", marginBottom: 24 }}>
              The Brand in One Line
            </div>
            <div style={{ fontSize: "clamp(28px, 5vw, 48px)", color: "white", fontWeight: 400, letterSpacing: "-0.02em", marginBottom: 16 }}>
              Ové
            </div>
            <div style={{ fontSize: "clamp(16px, 2.5vw, 22px)", color: "#93b4d4", fontStyle: "italic" }}>
              "From someday to today."
            </div>
          </div>
        </section>

      </div>
    </div>
  );
}
