import { useState } from "react";

const sections = [
  {
    id: "problem",
    number: "01",
    title: "The Problem You Solve",
    subtitle: "What pain does your product eliminate?",
    placeholder: "e.g. People feel overwhelmed and ashamed about their finances — they avoid looking at their money because it's stressful.",
    hint: "💡 The sharper the pain, the stronger the positioning. Go emotional, not just functional.",
    examples: ["Paycheck-to-paycheck anxiety", "No idea where money goes each month", "Too intimidated to start investing"],
  },
  {
    id: "audience",
    number: "02",
    title: "Your Target Person",
    subtitle: "Who is this built for, specifically?",
    placeholder: "e.g. 25–35 year olds earning $40–80k who are not broke but feel like they should be doing better with money.",
    hint: "💡 'Everyone' is nobody. The more specific, the more magnetic your brand.",
    examples: ["New grads with first real job", "Millennials who ignored their finances in their 20s", "Couples managing shared finances for the first time"],
  },
  {
    id: "insight",
    number: "03",
    title: "Your Unique Insight",
    subtitle: "What do you understand about this problem that others miss?",
    placeholder: "e.g. People don't need more budgeting features — they need to feel in control and confident, not judged.",
    hint: "💡 This is your secret weapon. It's the 'aha' that makes your product inevitable.",
    examples: ["Shame is the #1 reason people avoid their finances", "Automation removes willpower from the equation", "Most apps are built for people who already have money habits"],
  },
  {
    id: "solution",
    number: "04",
    title: "What You Offer",
    subtitle: "Describe your product in plain, vivid terms",
    placeholder: "e.g. A calm, judgment-free financial companion that shows you exactly where you stand and what to do next — in under 5 minutes a week.",
    hint: "💡 Avoid jargon. Describe the experience, not just the features.",
    examples: ["Automated savings that work invisibly in the background", "A weekly money check-in that takes 3 minutes", "AI that learns your habits and nudges you gently"],
  },
  {
    id: "differentiation",
    number: "05",
    title: "Why You, Not Them",
    subtitle: "How are you meaningfully different from alternatives?",
    placeholder: "e.g. Unlike Mint or YNAB, we don't make you feel like a failure. We meet people where they are and make small progress feel like a win.",
    hint: "💡 Competitors aren't just direct rivals — 'doing nothing' or 'using a spreadsheet' counts too.",
    examples: ["No shaming, no complexity", "Designed for irregular income (gig workers)", "Couples-first vs individual-first"],
  },
  {
    id: "promise",
    number: "06",
    title: "Your Brand Promise",
    subtitle: "What transformation do you deliver?",
    placeholder: "e.g. From financial anxiety to quiet confidence — in 90 days.",
    hint: "💡 This is the emotional 'before → after'. Keep it short enough to remember.",
    examples: ["From avoiding to owning your money", "The first finance app that feels like a friend", "Know your number. Live your life."],
  },
];

const positioningStatement = (data) => {
  const { audience, problem, solution, differentiation, promise } = data;
  if (!audience && !problem && !solution) return null;
  return `For ${audience || "[your audience]"} who struggle with ${problem || "[the problem]"}, we offer ${solution || "[your solution]"} — unlike alternatives that ${differentiation || "[competitor weakness]"}. Our promise: ${promise || "[your transformation]"}.`;
};

export default function BrandCanvas() {
  const [answers, setAnswers] = useState({});
  const [activeSection, setActiveSection] = useState(null);
  const [showStatement, setShowStatement] = useState(false);

  const completedCount = Object.values(answers).filter(v => v && v.trim().length > 10).length;
  const progress = Math.round((completedCount / sections.length) * 100);

  const handleInput = (id, value) => {
    setAnswers(prev => ({ ...prev, [id]: value }));
  };

  const statement = positioningStatement({
    audience: answers.audience,
    problem: answers.problem,
    solution: answers.solution,
    differentiation: answers.differentiation,
    promise: answers.promise,
  });

  return (
    <div style={{
      minHeight: "100vh",
      background: "#0a0a0f",
      fontFamily: "'Georgia', 'Times New Roman', serif",
      color: "#f0ece4",
      padding: "0",
    }}>
      {/* Header */}
      <div style={{
        borderBottom: "1px solid #1e1e2e",
        padding: "32px 40px 28px",
        background: "linear-gradient(135deg, #0d0d1a 0%, #0a0a0f 100%)",
        position: "sticky",
        top: 0,
        zIndex: 10,
        backdropFilter: "blur(12px)",
      }}>
        <div style={{ maxWidth: 900, margin: "0 auto", display: "flex", alignItems: "flex-end", justifyContent: "space-between", flexWrap: "wrap", gap: 16 }}>
          <div>
            <div style={{ fontSize: 11, letterSpacing: "0.25em", color: "#5a9fd4", textTransform: "uppercase", marginBottom: 6, fontFamily: "monospace" }}>
              Personal Finance · Digital Product
            </div>
            <h1 style={{ margin: 0, fontSize: "clamp(22px, 4vw, 34px)", fontWeight: 400, letterSpacing: "-0.02em", color: "#f0ece4" }}>
              Brand Positioning Canvas
            </h1>
          </div>
          <div style={{ textAlign: "right" }}>
            <div style={{ fontSize: 11, color: "#5a9fd4", letterSpacing: "0.15em", textTransform: "uppercase", fontFamily: "monospace", marginBottom: 6 }}>
              {completedCount} of {sections.length} complete
            </div>
            <div style={{ width: 180, height: 3, background: "#1e1e2e", borderRadius: 2 }}>
              <div style={{
                width: `${progress}%`,
                height: "100%",
                background: "linear-gradient(90deg, #5a9fd4, #a78bfa)",
                borderRadius: 2,
                transition: "width 0.4s ease",
              }} />
            </div>
          </div>
        </div>
      </div>

      <div style={{ maxWidth: 900, margin: "0 auto", padding: "40px 40px 80px" }}>

        {/* Intro */}
        <div style={{
          background: "linear-gradient(135deg, #111128 0%, #0f0f1f 100%)",
          border: "1px solid #1e1e2e",
          borderRadius: 12,
          padding: "28px 32px",
          marginBottom: 40,
        }}>
          <p style={{ margin: 0, fontSize: 15, lineHeight: 1.75, color: "#b0aaa0" }}>
            Answer these 6 questions to define your brand's strategic foundation. Don't worry about being polished — think out loud. 
            Use the examples as sparks, not constraints. When you're done, your positioning statement will generate automatically.
          </p>
        </div>

        {/* Sections */}
        {sections.map((section, i) => {
          const isActive = activeSection === section.id;
          const isFilled = answers[section.id] && answers[section.id].trim().length > 10;

          return (
            <div
              key={section.id}
              onClick={() => setActiveSection(isActive ? null : section.id)}
              style={{
                marginBottom: 16,
                border: `1px solid ${isActive ? "#5a9fd4" : isFilled ? "#2a3a2a" : "#1e1e2e"}`,
                borderRadius: 12,
                overflow: "hidden",
                cursor: "pointer",
                transition: "border-color 0.2s ease, box-shadow 0.2s ease",
                boxShadow: isActive ? "0 0 0 1px #5a9fd430" : "none",
                background: isActive ? "#0d1220" : "#0e0e18",
              }}
            >
              {/* Section Header */}
              <div style={{
                padding: "22px 28px",
                display: "flex",
                alignItems: "center",
                gap: 20,
              }}>
                <div style={{
                  fontSize: 11,
                  fontFamily: "monospace",
                  color: isActive ? "#5a9fd4" : isFilled ? "#4ade80" : "#3a3a4a",
                  letterSpacing: "0.1em",
                  minWidth: 26,
                  transition: "color 0.2s",
                }}>
                  {isFilled ? "✓" : section.number}
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{
                    fontSize: 17,
                    fontWeight: 400,
                    color: isActive ? "#f0ece4" : isFilled ? "#d0ccc4" : "#807a70",
                    marginBottom: 2,
                    transition: "color 0.2s",
                  }}>
                    {section.title}
                  </div>
                  <div style={{ fontSize: 12, color: "#5a5465", letterSpacing: "0.02em" }}>
                    {section.subtitle}
                  </div>
                </div>
                {isFilled && !isActive && (
                  <div style={{
                    fontSize: 12,
                    color: "#6b7280",
                    maxWidth: 260,
                    overflow: "hidden",
                    textOverflow: "ellipsis",
                    whiteSpace: "nowrap",
                    fontStyle: "italic",
                  }}>
                    {answers[section.id]}
                  </div>
                )}
                <div style={{
                  color: "#3a3a4a",
                  fontSize: 18,
                  transform: isActive ? "rotate(180deg)" : "rotate(0)",
                  transition: "transform 0.25s ease",
                }}>
                  ↓
                </div>
              </div>

              {/* Expanded Content */}
              {isActive && (
                <div
                  onClick={e => e.stopPropagation()}
                  style={{ padding: "0 28px 28px" }}
                >
                  <div style={{
                    fontSize: 12,
                    color: "#a78bfa",
                    background: "#1a1428",
                    border: "1px solid #2d2040",
                    borderRadius: 8,
                    padding: "12px 16px",
                    marginBottom: 16,
                    fontFamily: "monospace",
                    letterSpacing: "0.01em",
                  }}>
                    {section.hint}
                  </div>

                  <textarea
                    value={answers[section.id] || ""}
                    onChange={e => handleInput(section.id, e.target.value)}
                    placeholder={section.placeholder}
                    rows={4}
                    style={{
                      width: "100%",
                      background: "#07070f",
                      border: "1px solid #2a2a3e",
                      borderRadius: 8,
                      padding: "16px",
                      fontSize: 14,
                      color: "#e0dcd4",
                      lineHeight: 1.7,
                      resize: "vertical",
                      outline: "none",
                      fontFamily: "'Georgia', serif",
                      boxSizing: "border-box",
                      marginBottom: 16,
                    }}
                  />

                  <div>
                    <div style={{ fontSize: 11, color: "#4a4a5a", letterSpacing: "0.15em", textTransform: "uppercase", marginBottom: 10, fontFamily: "monospace" }}>
                      Starter sparks →
                    </div>
                    <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
                      {section.examples.map((ex, j) => (
                        <button
                          key={j}
                          onClick={() => handleInput(section.id, (answers[section.id] ? answers[section.id] + " " : "") + ex)}
                          style={{
                            background: "transparent",
                            border: "1px solid #2a2a3e",
                            borderRadius: 20,
                            padding: "6px 14px",
                            fontSize: 12,
                            color: "#7a7498",
                            cursor: "pointer",
                            fontFamily: "'Georgia', serif",
                            transition: "all 0.15s ease",
                          }}
                          onMouseEnter={e => { e.target.style.borderColor = "#5a9fd4"; e.target.style.color = "#5a9fd4"; }}
                          onMouseLeave={e => { e.target.style.borderColor = "#2a2a3e"; e.target.style.color = "#7a7498"; }}
                        >
                          + {ex}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          );
        })}

        {/* Positioning Statement */}
        <div style={{
          marginTop: 40,
          border: `1px solid ${showStatement ? "#a78bfa" : "#1e1e2e"}`,
          borderRadius: 12,
          overflow: "hidden",
          background: showStatement ? "linear-gradient(135deg, #130f20 0%, #0d0d1a 100%)" : "#0e0e18",
          transition: "all 0.3s ease",
        }}>
          <div
            onClick={() => setShowStatement(!showStatement)}
            style={{
              padding: "22px 28px",
              cursor: "pointer",
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
            }}
          >
            <div>
              <div style={{ fontSize: 17, color: showStatement ? "#e0dcd4" : "#807a70" }}>
                ✦ Your Positioning Statement
              </div>
              <div style={{ fontSize: 12, color: "#5a5465", marginTop: 2 }}>
                Auto-generated from your answers · refine as you go
              </div>
            </div>
            <div style={{ color: "#a78bfa", fontSize: 12, fontFamily: "monospace", letterSpacing: "0.1em" }}>
              {showStatement ? "HIDE ↑" : "REVEAL ↓"}
            </div>
          </div>

          {showStatement && (
            <div style={{ padding: "0 28px 32px" }}>
              {statement ? (
                <>
                  <div style={{
                    background: "#07070f",
                    border: "1px solid #2d2040",
                    borderRadius: 10,
                    padding: "24px 28px",
                    fontSize: 16,
                    lineHeight: 1.85,
                    color: "#d0ccc4",
                    fontStyle: "italic",
                    marginBottom: 20,
                  }}>
                    "{statement}"
                  </div>
                  <div style={{ fontSize: 12, color: "#5a5465", fontFamily: "monospace", lineHeight: 1.7 }}>
                    This is a working draft. Edit your answers above to refine it. Once solid, this becomes your north star — for naming, copy, pitch decks, and hiring.
                  </div>
                </>
              ) : (
                <div style={{
                  background: "#07070f",
                  border: "1px dashed #2a2a3e",
                  borderRadius: 10,
                  padding: "24px",
                  fontSize: 14,
                  color: "#4a4a5a",
                  textAlign: "center",
                  fontStyle: "italic",
                }}>
                  Fill in at least your audience, problem, and solution above to generate your statement.
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer note */}
        <div style={{
          marginTop: 32,
          textAlign: "center",
          fontSize: 12,
          color: "#3a3a4a",
          fontFamily: "monospace",
          letterSpacing: "0.1em",
        }}>
          PERSONAL FINANCE · DIGITAL PRODUCT · BRAND POSITIONING v1
        </div>
      </div>
    </div>
  );
}
