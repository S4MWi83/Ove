import { useState } from "react";

const namingDirections = [
  {
    direction: "The First Step",
    rationale: "Names that celebrate the act of beginning — emotionally resonant with your 'someday to started' promise.",
    color: "#5a9fd4",
    accent: "#5a9fd420",
    names: [
      { name: "Primo", tagline: "Your first investment. Not your last.", note: "Latin for 'first' — short, punchy, memorable" },
      { name: "Fledge", tagline: "Start small. Grow for real.", note: "A fledgling taking flight — becoming independent" },
      { name: "Stepwise", tagline: "One step. That's all it takes.", note: "Literally about taking the first step" },
      { name: "Onset", tagline: "The hardest part is starting. We fixed that.", note: "Clean, modern, implies momentum" },
    ],
  },
  {
    direction: "Radical Simplicity",
    rationale: "Names that signal 'we stripped everything away' — the anti-complexity brand.",
    color: "#a78bfa",
    accent: "#a78bfa20",
    names: [
      { name: "Clearr", tagline: "Investing, finally clear.", note: "Double-r feels fresh and ownable" },
      { name: "Pare", tagline: "Investing stripped to its essentials.", note: "To pare = to strip away complexity" },
      { name: "Plainvest", tagline: "Plain and simple. Just like investing should be.", note: "Compound — plain + invest" },
      { name: "Zerø", tagline: "Zero barriers. Zero jargon. Just growth.", note: "The symbol adds edge; implies starting from nothing" },
    ],
  },
  {
    direction: "Speed & Momentum",
    rationale: "Names that embody the '2 minutes to started' brand promise — fast, forward-moving.",
    color: "#34d399",
    accent: "#34d39920",
    names: [
      { name: "Nudge", tagline: "The little push that changes everything.", note: "Behavioral economics term — gentle but powerful" },
      { name: "Spark", tagline: "Start something.", note: "Universal ignition metaphor — clean and broad" },
      { name: "Flint", tagline: "Strikes fast. Burns long.", note: "Flint makes fire — starting something lasting" },
      { name: "Zipvest", tagline: "Investing at the speed of now.", note: "Zip = fast + invest compound" },
    ],
  },
  {
    direction: "The Everyday Investor",
    rationale: "Names that make 'normal people' feel like they belong in investing — not intimidating, not exclusive.",
    color: "#fb923c",
    accent: "#fb923c20",
    names: [
      { name: "Commonstock", tagline: "Investing for the rest of us.", note: "Common = ordinary people; stock = investing" },
      { name: "Evervest", tagline: "For everyone. Starting now.", note: "Every + invest — inclusive and warm" },
      { name: "Grove", tagline: "Plant a little. Watch it grow.", note: "Nature metaphor — patient, organic growth" },
      { name: "Folks", tagline: "Investing built for real people.", note: "Warm, unpretentious, anti-Wall Street" },
    ],
  },
];

const taglineFormulas = [
  { formula: "Action + Outcome", example: "Start today. Grow forever.", why: "Direct, empowering, clear promise" },
  { formula: "Against the old way", example: "Investing wasn't built for you. We fixed that.", why: "Positions against incumbents" },
  { formula: "The number", example: "€1. 2 minutes. One decision.", why: "Concrete proof of simplicity" },
  { formula: "The transformation", example: "From someday to started.", why: "Mirrors your brand promise perfectly" },
  { formula: "Permission", example: "You don't need to know everything. Just start.", why: "Removes the fear barrier directly" },
];

export default function NamingExplorer() {
  const [saved, setSaved] = useState([]);
  const [activeDirection, setActiveDirection] = useState(0);
  const [view, setView] = useState("names"); // names | taglines | shortlist

  const toggleSave = (name) => {
    setSaved(prev => prev.includes(name) ? prev.filter(n => n !== name) : [...prev, name]);
  };

  const current = namingDirections[activeDirection];

  return (
    <div style={{
      minHeight: "100vh",
      background: "#0a0a0f",
      fontFamily: "'Georgia', 'Times New Roman', serif",
      color: "#f0ece4",
    }}>
      {/* Header */}
      <div style={{
        padding: "40px 40px 32px",
        borderBottom: "1px solid #1a1a2e",
        background: "linear-gradient(135deg, #0d0d1a 0%, #0a0a0f 100%)",
        position: "sticky", top: 0, zIndex: 10,
        backdropFilter: "blur(12px)",
      }}>
        <div style={{ maxWidth: 860, margin: "0 auto", display: "flex", alignItems: "flex-end", justifyContent: "space-between", flexWrap: "wrap", gap: 16 }}>
          <div>
            <div style={{ fontSize: 11, letterSpacing: "0.25em", color: "#5a9fd4", textTransform: "uppercase", marginBottom: 8, fontFamily: "monospace" }}>
              Step 2 of 4 · Brand Development
            </div>
            <h1 style={{ margin: 0, fontSize: "clamp(22px, 4vw, 32px)", fontWeight: 400, letterSpacing: "-0.02em" }}>
              Naming & Tagline Explorer
            </h1>
          </div>
          <div style={{ display: "flex", gap: 8 }}>
            {["names", "taglines", "shortlist"].map(v => (
              <button key={v} onClick={() => setView(v)} style={{
                background: view === v ? "#1a1a2e" : "transparent",
                border: `1px solid ${view === v ? "#5a9fd4" : "#2a2a3e"}`,
                borderRadius: 20,
                padding: "7px 16px",
                fontSize: 11,
                color: view === v ? "#5a9fd4" : "#5a5465",
                cursor: "pointer",
                fontFamily: "monospace",
                letterSpacing: "0.1em",
                textTransform: "uppercase",
              }}>
                {v}{v === "shortlist" && saved.length > 0 ? ` (${saved.length})` : ""}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div style={{ maxWidth: 860, margin: "0 auto", padding: "40px 40px 80px" }}>

        {/* NAMES VIEW */}
        {view === "names" && (
          <>
            {/* Direction Tabs */}
            <div style={{ display: "flex", gap: 10, marginBottom: 32, flexWrap: "wrap" }}>
              {namingDirections.map((dir, i) => (
                <button key={i} onClick={() => setActiveDirection(i)} style={{
                  background: activeDirection === i ? dir.accent : "transparent",
                  border: `1px solid ${activeDirection === i ? dir.color : "#2a2a3e"}`,
                  borderRadius: 8,
                  padding: "10px 18px",
                  fontSize: 13,
                  color: activeDirection === i ? dir.color : "#6a6480",
                  cursor: "pointer",
                  fontFamily: "'Georgia', serif",
                  transition: "all 0.2s ease",
                }}>
                  {dir.direction}
                </button>
              ))}
            </div>

            {/* Rationale */}
            <div style={{
              background: "#0e0e18",
              border: `1px solid ${current.color}30`,
              borderRadius: 10,
              padding: "16px 20px",
              marginBottom: 24,
              fontSize: 13,
              color: "#8a8498",
              lineHeight: 1.7,
              fontStyle: "italic",
            }}>
              {current.rationale}
            </div>

            {/* Name Cards */}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(340px, 1fr))", gap: 16 }}>
              {current.names.map((item, i) => {
                const isSaved = saved.includes(item.name);
                return (
                  <div key={i} style={{
                    background: "#0e0e18",
                    border: `1px solid ${isSaved ? current.color + "60" : "#1e1e2e"}`,
                    borderRadius: 12,
                    padding: "28px",
                    position: "relative",
                    overflow: "hidden",
                    transition: "border-color 0.2s ease",
                  }}>
                    {isSaved && (
                      <div style={{
                        position: "absolute", top: 0, left: 0, right: 0, height: 2,
                        background: `linear-gradient(90deg, ${current.color}, transparent)`,
                      }} />
                    )}
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 14 }}>
                      <div style={{
                        fontSize: "clamp(28px, 5vw, 36px)",
                        fontWeight: 400,
                        letterSpacing: "-0.03em",
                        color: "#f0ece4",
                      }}>
                        {item.name}
                      </div>
                      <button onClick={() => toggleSave(item.name)} style={{
                        background: isSaved ? current.accent : "transparent",
                        border: `1px solid ${isSaved ? current.color : "#2a2a3e"}`,
                        borderRadius: 20,
                        padding: "5px 12px",
                        fontSize: 11,
                        color: isSaved ? current.color : "#4a4a5a",
                        cursor: "pointer",
                        fontFamily: "monospace",
                        letterSpacing: "0.1em",
                      }}>
                        {isSaved ? "✓ SAVED" : "+ SAVE"}
                      </button>
                    </div>
                    <div style={{
                      fontSize: 14,
                      color: current.color,
                      marginBottom: 12,
                      fontStyle: "italic",
                    }}>
                      "{item.tagline}"
                    </div>
                    <div style={{ fontSize: 12, color: "#4a4a5a", lineHeight: 1.6, fontFamily: "monospace" }}>
                      {item.note}
                    </div>
                  </div>
                );
              })}
            </div>
          </>
        )}

        {/* TAGLINES VIEW */}
        {view === "taglines" && (
          <>
            <div style={{
              background: "#0e0e18",
              border: "1px solid #1e1e2e",
              borderRadius: 10,
              padding: "20px 24px",
              marginBottom: 32,
              fontSize: 13,
              color: "#8a8498",
              lineHeight: 1.7,
            }}>
              A great tagline works with any name. These formulas are all rooted in your positioning — pick the one that feels most <em>you</em>.
            </div>

            <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
              {taglineFormulas.map((t, i) => (
                <div key={i} style={{
                  background: "#0e0e18",
                  border: "1px solid #1e1e2e",
                  borderRadius: 12,
                  padding: "28px 32px",
                  display: "grid",
                  gridTemplateColumns: "180px 1fr",
                  gap: 24,
                  alignItems: "center",
                }}>
                  <div>
                    <div style={{ fontSize: 10, fontFamily: "monospace", color: "#a78bfa", letterSpacing: "0.15em", textTransform: "uppercase", marginBottom: 6 }}>
                      Formula
                    </div>
                    <div style={{ fontSize: 13, color: "#7a7498" }}>{t.formula}</div>
                  </div>
                  <div>
                    <div style={{ fontSize: "clamp(16px, 2.5vw, 20px)", color: "#f0ece4", marginBottom: 10, fontStyle: "italic" }}>
                      "{t.example}"
                    </div>
                    <div style={{ fontSize: 12, color: "#4a4a5a", fontFamily: "monospace" }}>→ {t.why}</div>
                  </div>
                </div>
              ))}
            </div>
          </>
        )}

        {/* SHORTLIST VIEW */}
        {view === "shortlist" && (
          <>
            {saved.length === 0 ? (
              <div style={{
                textAlign: "center",
                padding: "80px 40px",
                color: "#3a3a4a",
                fontSize: 15,
                fontStyle: "italic",
              }}>
                No names saved yet — go to Names and hit + Save on your favourites.
              </div>
            ) : (
              <>
                <div style={{
                  background: "#0e0e18",
                  border: "1px solid #1e1e2e",
                  borderRadius: 10,
                  padding: "16px 20px",
                  marginBottom: 32,
                  fontSize: 13,
                  color: "#8a8498",
                  fontStyle: "italic",
                }}>
                  Your shortlist. Share these with a co-founder, a friend, or your potential users. The best name is the one that feels right AND tests well.
                </div>
                <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                  {saved.map((name, i) => {
                    const found = namingDirections.flatMap(d => d.names).find(n => n.name === name);
                    const dir = namingDirections.find(d => d.names.some(n => n.name === name));
                    return (
                      <div key={i} style={{
                        background: "#0e0e18",
                        border: "1px solid #1e1e2e",
                        borderRadius: 12,
                        padding: "24px 28px",
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                        gap: 20,
                        flexWrap: "wrap",
                      }}>
                        <div>
                          <div style={{ fontSize: 28, fontWeight: 400, letterSpacing: "-0.02em", color: "#f0ece4", marginBottom: 6 }}>
                            {name}
                          </div>
                          <div style={{ fontSize: 13, color: dir?.color, fontStyle: "italic" }}>
                            "{found?.tagline}"
                          </div>
                        </div>
                        <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
                          <div style={{
                            fontSize: 10, fontFamily: "monospace", color: "#4a4a5a",
                            border: "1px solid #1e1e2e", borderRadius: 20, padding: "4px 12px",
                            letterSpacing: "0.1em", textTransform: "uppercase",
                          }}>
                            {dir?.direction}
                          </div>
                          <button onClick={() => toggleSave(name)} style={{
                            background: "transparent",
                            border: "1px solid #2a2a3e",
                            borderRadius: 20,
                            padding: "5px 12px",
                            fontSize: 11,
                            color: "#4a4a5a",
                            cursor: "pointer",
                            fontFamily: "monospace",
                          }}>
                            ✕ Remove
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </>
            )}
          </>
        )}
      </div>
    </div>
  );
}
