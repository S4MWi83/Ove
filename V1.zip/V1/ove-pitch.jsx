export default function OvePitch() {
  return (
    <div style={{
      minHeight: "100vh",
      background: "#0a1628",
      fontFamily: "'Georgia', 'Times New Roman', serif",
      color: "#f0ece4",
    }}>
      <style>{`
        @keyframes fadeUp {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .fade-1 { animation: fadeUp 0.5s ease forwards; }
        .fade-2 { animation: fadeUp 0.5s 0.1s ease both; }
        .fade-3 { animation: fadeUp 0.5s 0.2s ease both; }
        .fade-4 { animation: fadeUp 0.5s 0.3s ease both; }
        .fade-5 { animation: fadeUp 0.5s 0.4s ease both; }
        .fade-6 { animation: fadeUp 0.5s 0.5s ease both; }
        .fade-7 { animation: fadeUp 0.5s 0.6s ease both; }
        @media print {
          body { background: white; }
        }
      `}</style>

      {/* HERO */}
      <div style={{
        background: "linear-gradient(160deg, #0a1628 0%, #0d2444 50%, #0a1e3d 100%)",
        padding: "72px 60px 64px",
        borderBottom: "1px solid #1a2a40",
        position: "relative",
        overflow: "hidden",
      }}>
        <div style={{ position: "absolute", top: -100, right: -100, width: 500, height: 500, borderRadius: "50%", background: "radial-gradient(circle, #3b82f610, transparent 70%)", pointerEvents: "none" }} />
        <div style={{ position: "absolute", bottom: -80, left: -80, width: 400, height: 400, borderRadius: "50%", background: "radial-gradient(circle, #6366f108, transparent 70%)", pointerEvents: "none" }} />

        <div style={{ maxWidth: 960, margin: "0 auto" }}>
          <div className="fade-1" style={{ display: "flex", alignItems: "center", gap: 16, marginBottom: 40 }}>
            <div style={{
              width: 48, height: 48, borderRadius: "50%",
              border: "1.5px solid #3b82f6",
              display: "flex", alignItems: "center", justifyContent: "center",
            }}>
              <svg width="20" height="20" viewBox="0 0 20 20" fill="none">
                <path d="M4 10L10 4L16 10" stroke="#3b82f6" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M10 4L10 16" stroke="#3b82f6" strokeWidth="2" strokeLinecap="round"/>
              </svg>
            </div>
            <span style={{ fontSize: 32, fontWeight: 400, letterSpacing: "-0.03em" }}>Ové</span>
            <div style={{ width: 1, height: 28, background: "#ffffff15", margin: "0 4px" }} />
            <span style={{ fontSize: 13, color: "#4a6a8a", fontFamily: "monospace", letterSpacing: "0.1em" }}>ONE-PAGE PITCH · 2026</span>
          </div>

          <div className="fade-2" style={{ maxWidth: 680 }}>
            <h1 style={{ margin: "0 0 20px", fontSize: "clamp(32px, 5vw, 52px)", fontWeight: 400, letterSpacing: "-0.03em", lineHeight: 1.15, color: "#ffffff" }}>
              From someday<br />to today.
            </h1>
            <p style={{ margin: "0 0 36px", fontSize: 18, color: "#6a8aaa", lineHeight: 1.75 }}>
              The investing app built for the 70% of people who want to invest but never start.
            </p>
            <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
              {["€1 minimum", "2-minute onboarding", "Zero jargon", "European market"].map((tag, i) => (
                <div key={i} style={{
                  fontSize: 12, fontFamily: "monospace", letterSpacing: "0.08em",
                  color: "#3b82f6", background: "#3b82f612",
                  border: "1px solid #3b82f630",
                  borderRadius: 20, padding: "6px 14px",
                }}>
                  {tag}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div style={{ maxWidth: 960, margin: "0 auto", padding: "56px 60px 80px" }}>

        {/* THE PROBLEM + OPPORTUNITY */}
        <div className="fade-3" style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20, marginBottom: 24 }}>
          <div style={{
            background: "#0e1e32",
            border: "1px solid #1a2a40",
            borderRadius: 16,
            padding: "36px",
          }}>
            <div style={{ fontSize: 11, fontFamily: "monospace", letterSpacing: "0.2em", color: "#ef4444", textTransform: "uppercase", marginBottom: 20 }}>
              The Problem
            </div>
            <p style={{ margin: "0 0 24px", fontSize: 15, color: "#8aa0b8", lineHeight: 1.8 }}>
              Most people want to invest. Almost none of them do.
            </p>
            <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
              {[
                { stat: "70%", desc: "of Europeans have no investments" },
                { stat: "3x", desc: "more steps to open a trading account vs. a social media account" },
                { stat: "#1", desc: "reason: 'it feels too complicated'" },
              ].map((item, i) => (
                <div key={i} style={{ display: "flex", alignItems: "baseline", gap: 14 }}>
                  <div style={{ fontSize: 28, fontWeight: 400, color: "#ef4444", letterSpacing: "-0.02em", minWidth: 52 }}>{item.stat}</div>
                  <div style={{ fontSize: 13, color: "#6a8aaa", lineHeight: 1.5 }}>{item.desc}</div>
                </div>
              ))}
            </div>
          </div>

          <div style={{
            background: "#0e1e32",
            border: "1px solid #1a2a40",
            borderRadius: 16,
            padding: "36px",
          }}>
            <div style={{ fontSize: 11, fontFamily: "monospace", letterSpacing: "0.2em", color: "#3b82f6", textTransform: "uppercase", marginBottom: 20 }}>
              The Opportunity
            </div>
            <p style={{ margin: "0 0 24px", fontSize: 15, color: "#8aa0b8", lineHeight: 1.8 }}>
              No European investing app is truly built for the first-timer.
            </p>
            <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
              {[
                { stat: "€2.4T", desc: "in European savings accounts earning near-zero interest" },
                { stat: "340M", desc: "working-age Europeans, majority with no investment account" },
                { stat: "0", desc: "apps that make the first step genuinely frictionless" },
              ].map((item, i) => (
                <div key={i} style={{ display: "flex", alignItems: "baseline", gap: 14 }}>
                  <div style={{ fontSize: 28, fontWeight: 400, color: "#3b82f6", letterSpacing: "-0.02em", minWidth: 52 }}>{item.stat}</div>
                  <div style={{ fontSize: 13, color: "#6a8aaa", lineHeight: 1.5 }}>{item.desc}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* SOLUTION */}
        <div className="fade-4" style={{
          background: "linear-gradient(135deg, #0d2040, #111830)",
          border: "1px solid #3b82f630",
          borderRadius: 16,
          padding: "40px 44px",
          marginBottom: 24,
        }}>
          <div style={{ fontSize: 11, fontFamily: "monospace", letterSpacing: "0.2em", color: "#3b82f6", textTransform: "uppercase", marginBottom: 24 }}>
            The Solution
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 40, alignItems: "center" }}>
            <div>
              <h2 style={{ margin: "0 0 16px", fontSize: "clamp(20px, 3vw, 28px)", fontWeight: 400, letterSpacing: "-0.02em", color: "#ffffff", lineHeight: 1.3 }}>
                Ové removes every barrier between a person and their first investment.
              </h2>
              <p style={{ margin: 0, fontSize: 14, color: "#6a8aaa", lineHeight: 1.8 }}>
                No jargon. No minimums. No confusion. Sign up in under 2 minutes, invest from €1, and let the app handle everything else.
              </p>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
              {[
                { icon: "⚡", label: "2-min onboarding", desc: "Fastest in market" },
                { icon: "€", label: "Start with €1", desc: "No minimum balance" },
                { icon: "◎", label: "3 portfolios", desc: "Plain language only" },
                { icon: "✦", label: "Built for beginners", desc: "Not traders" },
              ].map((f, i) => (
                <div key={i} style={{
                  background: "#0a1628",
                  border: "1px solid #1a2a40",
                  borderRadius: 10,
                  padding: "16px",
                }}>
                  <div style={{ fontSize: 18, marginBottom: 8 }}>{f.icon}</div>
                  <div style={{ fontSize: 12, color: "#d0ccc4", marginBottom: 3 }}>{f.label}</div>
                  <div style={{ fontSize: 11, color: "#4a6a8a", fontFamily: "monospace" }}>{f.desc}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* BUSINESS MODEL + TRACTION */}
        <div className="fade-5" style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20, marginBottom: 24 }}>
          <div style={{
            background: "#0e1e32",
            border: "1px solid #1a2a40",
            borderRadius: 16,
            padding: "36px",
          }}>
            <div style={{ fontSize: 11, fontFamily: "monospace", letterSpacing: "0.2em", color: "#a78bfa", textTransform: "uppercase", marginBottom: 20 }}>
              Business Model
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
              {[
                { stream: "AUM fee", desc: "0.5% annual fee on assets under management — scales with user growth", primary: true },
                { stream: "Ové Plus", desc: "€4.99/month for advanced features: auto-investing, tax reports, multi-portfolio", primary: false },
                { stream: "Referral", desc: "Partner revenue from regulated broker infrastructure", primary: false },
              ].map((item, i) => (
                <div key={i} style={{
                  padding: "14px 16px",
                  background: item.primary ? "#1a1a40" : "#0a1628",
                  border: `1px solid ${item.primary ? "#a78bfa40" : "#1a2a40"}`,
                  borderRadius: 10,
                }}>
                  <div style={{ fontSize: 13, color: item.primary ? "#a78bfa" : "#8aa0b8", marginBottom: 4 }}>{item.stream}</div>
                  <div style={{ fontSize: 12, color: "#4a6a8a", lineHeight: 1.5 }}>{item.desc}</div>
                </div>
              ))}
            </div>
          </div>

          <div style={{
            background: "#0e1e32",
            border: "1px solid #1a2a40",
            borderRadius: 16,
            padding: "36px",
          }}>
            <div style={{ fontSize: 11, fontFamily: "monospace", letterSpacing: "0.2em", color: "#34d399", textTransform: "uppercase", marginBottom: 20 }}>
              Why Now
            </div>
            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              {[
                "EU retail investment regulation pushing financial inclusion",
                "Post-pandemic savings glut — Europeans have more to invest than ever",
                "Gen Z & Millennial distrust of banks creates fintech openness",
                "Mobile-first generation ready for a mobile-first investment experience",
                "Rising inflation making 'do nothing' visibly costly",
              ].map((point, i) => (
                <div key={i} style={{ display: "flex", gap: 12, alignItems: "flex-start" }}>
                  <div style={{ color: "#34d399", fontSize: 14, marginTop: 1, flexShrink: 0 }}>+</div>
                  <div style={{ fontSize: 13, color: "#6a8aaa", lineHeight: 1.6 }}>{point}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* COMPETITIVE POSITION */}
        <div className="fade-6" style={{
          background: "#0e1e32",
          border: "1px solid #1a2a40",
          borderRadius: 16,
          padding: "36px 40px",
          marginBottom: 24,
        }}>
          <div style={{ fontSize: 11, fontFamily: "monospace", letterSpacing: "0.2em", color: "#f59e0b", textTransform: "uppercase", marginBottom: 24 }}>
            Competitive Position
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 12 }}>
            {[
              { name: "Ové", simplicity: 5, beginner: 5, eu: true, color: "#3b82f6" },
              { name: "Acorns", simplicity: 4, beginner: 4, eu: false, color: "#4caf50" },
              { name: "Revolut", simplicity: 3, beginner: 2, eu: true, color: "#94a3b8" },
              { name: "Trading 212", simplicity: 2, beginner: 2, eu: true, color: "#e91e63" },
            ].map((c, i) => (
              <div key={i} style={{
                background: c.name === "Ové" ? "#0d2040" : "#0a1628",
                border: `1px solid ${c.name === "Ové" ? "#3b82f640" : "#1a2a40"}`,
                borderRadius: 10,
                padding: "18px",
              }}>
                <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 14 }}>
                  <div style={{ width: 8, height: 8, borderRadius: "50%", background: c.color }} />
                  <span style={{ fontSize: 13, color: c.name === "Ové" ? "#ffffff" : "#8aa0b8" }}>{c.name}</span>
                </div>
                {[
                  { label: "Simplicity", val: c.simplicity },
                  { label: "Beginner", val: c.beginner },
                ].map((s, j) => (
                  <div key={j} style={{ marginBottom: 8 }}>
                    <div style={{ fontSize: 10, color: "#3a5a7a", fontFamily: "monospace", marginBottom: 4 }}>{s.label.toUpperCase()}</div>
                    <div style={{ display: "flex", gap: 3 }}>
                      {[1,2,3,4,5].map(n => (
                        <div key={n} style={{ flex: 1, height: 4, borderRadius: 2, background: n <= s.val ? c.color : "#1a2a40" }} />
                      ))}
                    </div>
                  </div>
                ))}
                <div style={{ fontSize: 10, color: c.eu ? "#34d399" : "#ef4444", fontFamily: "monospace", marginTop: 10 }}>
                  {c.eu ? "✓ EU" : "✗ US only"}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* VISION + CTA */}
        <div className="fade-7" style={{
          background: "linear-gradient(135deg, #0a1628, #0d2444)",
          border: "1px solid #3b82f620",
          borderRadius: 16,
          padding: "48px 44px",
          display: "grid",
          gridTemplateColumns: "1fr auto",
          gap: 40,
          alignItems: "center",
        }}>
          <div>
            <div style={{ fontSize: 11, fontFamily: "monospace", letterSpacing: "0.2em", color: "#3b82f6", textTransform: "uppercase", marginBottom: 16 }}>
              The Vision
            </div>
            <h2 style={{ margin: "0 0 14px", fontSize: "clamp(20px, 3vw, 28px)", fontWeight: 400, letterSpacing: "-0.02em", color: "#ffffff", lineHeight: 1.3 }}>
              Ové becomes the default first step<br />for every new investor in Europe.
            </h2>
            <p style={{ margin: 0, fontSize: 14, color: "#6a8aaa", lineHeight: 1.8, maxWidth: 480 }}>
              We win by owning the moment of first investment. Once someone starts with Ové, they grow with Ové. The retention flywheel starts with radical simplicity and builds with trust.
            </p>
          </div>
          <div style={{ textAlign: "center", minWidth: 180 }}>
            <div style={{
              fontSize: 48, fontWeight: 400, letterSpacing: "-0.04em", color: "#ffffff", marginBottom: 6,
            }}>Ové</div>
            <div style={{ fontSize: 14, color: "#6a8aaa", fontStyle: "italic", marginBottom: 24 }}>
              "From someday to today."
            </div>
            <div style={{
              fontSize: 11, fontFamily: "monospace", color: "#3b82f6",
              border: "1px solid #3b82f640",
              borderRadius: 8, padding: "10px 20px",
              letterSpacing: "0.1em",
            }}>
              app.ové.io
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
