import { useState } from "react";

const names = [
  {
    id: "firstleaf",
    name: "Firstleaf",
    tagline: "Your first investment. Finally.",
    direction: "The First Step",
    rationale: "Evokes new beginnings and organic growth. 'First' directly addresses the barrier — getting started. Warm, approachable, memorable.",
    feel: ["Warm", "Hopeful", "Organic"],
    score: { memorable: 5, simple: 4, trustworthy: 4, modern: 3 },
    color: "#4ade80",
  },
  {
    id: "nudge",
    name: "Nudge",
    tagline: "The gentle push your future self needs.",
    direction: "Behavioural",
    rationale: "Rooted in behavioural economics. Signals low-pressure, effortless action. One word, instantly understood, very brandable.",
    feel: ["Friendly", "Clever", "Light"],
    score: { memorable: 5, simple: 5, trustworthy: 3, modern: 5 },
    color: "#5a9fd4",
  },
  {
    id: "oneuro",
    name: "Uno",
    tagline: "Start with one. Build from there.",
    direction: "The Minimum",
    rationale: "Anchors the €1 minimum as the brand identity itself. Simple, international, ties to 'one step.' Works across Europe.",
    feel: ["Bold", "Simple", "Universal"],
    score: { memorable: 4, simple: 5, trustworthy: 4, modern: 4 },
    color: "#f59e0b",
  },
  {
    id: "plinth",
    name: "Plinth",
    tagline: "The foundation your money deserves.",
    direction: "The Foundation",
    rationale: "A plinth is the base everything stands on. Signals stability and long-term thinking. Distinctive, short, premium-feeling.",
    feel: ["Confident", "Premium", "Serious"],
    score: { memorable: 4, simple: 3, trustworthy: 5, modern: 4 },
    color: "#a78bfa",
  },
  {
    id: "sprout",
    name: "Sprout",
    tagline: "Small start. Big future.",
    direction: "Growth",
    rationale: "Growth metaphor that emphasises starting small. Friendly and optimistic without being naive. Appeals to the €1 minimum message.",
    feel: ["Optimistic", "Playful", "Accessible"],
    score: { memorable: 4, simple: 5, trustworthy: 4, modern: 3 },
    color: "#34d399",
  },
  {
    id: "clearpath",
    name: "Clearpath",
    tagline: "Investing. No confusion. Just start.",
    direction: "Clarity",
    rationale: "Directly attacks the complexity barrier. Says exactly what the product does emotionally — it removes the fog. Functional and trustworthy.",
    feel: ["Trustworthy", "Direct", "Clean"],
    score: { memorable: 3, simple: 4, trustworthy: 5, modern: 4 },
    color: "#38bdf8",
  },
];

const criteria = ["memorable", "simple", "trustworthy", "modern"];

export default function BrandNaming() {
  const [selected, setSelected] = useState(null);
  const [favorites, setFavorites] = useState([]);
  const [view, setView] = useState("grid"); // grid | compare

  const toggleFavorite = (id, e) => {
    e.stopPropagation();
    setFavorites(prev => prev.includes(id) ? prev.filter(f => f !== id) : [...prev, id]);
  };

  const selectedName = names.find(n => n.id === selected);

  return (
    <div style={{
      minHeight: "100vh",
      background: "#f7f4ef",
      fontFamily: "'Georgia', 'Times New Roman', serif",
      color: "#1a1a1a",
    }}>
      {/* Header */}
      <div style={{
        background: "#1a1a2e",
        padding: "40px 40px 36px",
        borderBottom: "3px solid #f7f4ef",
      }}>
        <div style={{ maxWidth: 900, margin: "0 auto" }}>
          <div style={{ fontSize: 10, letterSpacing: "0.35em", color: "#5a9fd4", textTransform: "uppercase", marginBottom: 10, fontFamily: "monospace" }}>
            Personal Finance Startup · Naming Round 1
          </div>
          <h1 style={{ margin: "0 0 6px", fontSize: "clamp(24px, 4vw, 38px)", fontWeight: 400, color: "#f0ece4", letterSpacing: "-0.02em" }}>
            Name & Tagline Explorer
          </h1>
          <p style={{ margin: 0, fontSize: 14, color: "#6a6880", maxWidth: 560 }}>
            6 directions, each rooted in your positioning. Click any card to explore it. Heart the ones that feel right.
          </p>
        </div>
      </div>

      <div style={{ maxWidth: 900, margin: "0 auto", padding: "40px 40px 80px" }}>

        {/* Toggle */}
        <div style={{ display: "flex", gap: 8, marginBottom: 32 }}>
          {["grid", "compare"].map(v => (
            <button key={v} onClick={() => setView(v)} style={{
              padding: "8px 20px",
              background: view === v ? "#1a1a2e" : "transparent",
              color: view === v ? "#f0ece4" : "#8a8070",
              border: `1px solid ${view === v ? "#1a1a2e" : "#d0cac0"}`,
              borderRadius: 24,
              cursor: "pointer",
              fontSize: 12,
              fontFamily: "monospace",
              letterSpacing: "0.1em",
              textTransform: "uppercase",
              transition: "all 0.2s",
            }}>
              {v === "grid" ? "Browse" : "Compare Scores"}
            </button>
          ))}
          {favorites.length > 0 && (
            <div style={{ marginLeft: "auto", fontSize: 12, color: "#8a8070", fontFamily: "monospace", alignSelf: "center" }}>
              ♥ {favorites.length} saved
            </div>
          )}
        </div>

        {view === "grid" && (
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))", gap: 20 }}>
            {names.map(n => {
              const isSelected = selected === n.id;
              const isFav = favorites.includes(n.id);
              return (
                <div
                  key={n.id}
                  onClick={() => setSelected(isSelected ? null : n.id)}
                  style={{
                    background: "#fff",
                    border: `2px solid ${isSelected ? n.color : "#e8e0d8"}`,
                    borderRadius: 14,
                    padding: "28px 24px 24px",
                    cursor: "pointer",
                    transition: "all 0.2s ease",
                    boxShadow: isSelected ? `0 8px 32px ${n.color}25` : "0 2px 8px #0000000a",
                    position: "relative",
                  }}
                >
                  {/* Direction tag */}
                  <div style={{
                    fontSize: 10,
                    fontFamily: "monospace",
                    letterSpacing: "0.2em",
                    textTransform: "uppercase",
                    color: n.color,
                    marginBottom: 14,
                  }}>
                    {n.direction}
                  </div>

                  {/* Name */}
                  <div style={{
                    fontSize: "clamp(28px, 5vw, 36px)",
                    fontWeight: 400,
                    letterSpacing: "-0.02em",
                    color: "#1a1a1a",
                    marginBottom: 10,
                    lineHeight: 1,
                  }}>
                    {n.name}
                  </div>

                  {/* Tagline */}
                  <div style={{
                    fontSize: 13,
                    color: "#6a6060",
                    fontStyle: "italic",
                    lineHeight: 1.6,
                    marginBottom: 18,
                    minHeight: 42,
                  }}>
                    "{n.tagline}"
                  </div>

                  {/* Feel tags */}
                  <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginBottom: 16 }}>
                    {n.feel.map(f => (
                      <span key={f} style={{
                        fontSize: 10,
                        padding: "3px 10px",
                        background: `${n.color}15`,
                        color: n.color,
                        borderRadius: 12,
                        fontFamily: "monospace",
                        letterSpacing: "0.05em",
                      }}>
                        {f}
                      </span>
                    ))}
                  </div>

                  {/* Expanded rationale */}
                  {isSelected && (
                    <div style={{
                      fontSize: 13,
                      color: "#5a5050",
                      lineHeight: 1.75,
                      borderTop: `1px solid ${n.color}30`,
                      paddingTop: 16,
                      marginTop: 4,
                    }}>
                      {n.rationale}
                    </div>
                  )}

                  {/* Favorite button */}
                  <button
                    onClick={e => toggleFavorite(n.id, e)}
                    style={{
                      position: "absolute",
                      top: 20,
                      right: 20,
                      background: "none",
                      border: "none",
                      cursor: "pointer",
                      fontSize: 18,
                      color: isFav ? "#f43f5e" : "#d0c8c0",
                      transition: "color 0.15s, transform 0.15s",
                      transform: isFav ? "scale(1.2)" : "scale(1)",
                      padding: 0,
                    }}
                  >
                    {isFav ? "♥" : "♡"}
                  </button>
                </div>
              );
            })}
          </div>
        )}

        {view === "compare" && (
          <div style={{ overflowX: "auto" }}>
            <table style={{ width: "100%", borderCollapse: "collapse", background: "#fff", borderRadius: 12, overflow: "hidden", boxShadow: "0 2px 12px #0000000a" }}>
              <thead>
                <tr style={{ background: "#1a1a2e" }}>
                  <th style={{ padding: "16px 20px", textAlign: "left", fontSize: 11, fontFamily: "monospace", letterSpacing: "0.15em", color: "#6a6880", textTransform: "uppercase", fontWeight: 400 }}>Name</th>
                  {criteria.map(c => (
                    <th key={c} style={{ padding: "16px 16px", textAlign: "center", fontSize: 11, fontFamily: "monospace", letterSpacing: "0.1em", color: "#6a6880", textTransform: "uppercase", fontWeight: 400 }}>{c}</th>
                  ))}
                  <th style={{ padding: "16px 16px", textAlign: "center", fontSize: 11, fontFamily: "monospace", color: "#6a6880", textTransform: "uppercase", fontWeight: 400 }}>Total</th>
                </tr>
              </thead>
              <tbody>
                {[...names].sort((a, b) => {
                  const sumA = criteria.reduce((s, c) => s + a.score[c], 0);
                  const sumB = criteria.reduce((s, c) => s + b.score[c], 0);
                  return sumB - sumA;
                }).map((n, i) => {
                  const total = criteria.reduce((s, c) => s + n.score[c], 0);
                  const isFav = favorites.includes(n.id);
                  return (
                    <tr key={n.id} style={{ borderBottom: "1px solid #f0ebe4", background: i === 0 ? `${n.color}08` : "transparent" }}>
                      <td style={{ padding: "16px 20px" }}>
                        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                          <span style={{ fontSize: 18, fontWeight: 400, color: "#1a1a1a" }}>{n.name}</span>
                          {i === 0 && <span style={{ fontSize: 10, fontFamily: "monospace", color: n.color, background: `${n.color}15`, padding: "2px 8px", borderRadius: 10 }}>TOP</span>}
                          {isFav && <span style={{ color: "#f43f5e", fontSize: 14 }}>♥</span>}
                        </div>
                        <div style={{ fontSize: 11, color: "#9a9088", fontStyle: "italic", marginTop: 2 }}>{n.direction}</div>
                      </td>
                      {criteria.map(c => (
                        <td key={c} style={{ padding: "16px", textAlign: "center" }}>
                          <div style={{ display: "flex", justifyContent: "center", gap: 2 }}>
                            {[1,2,3,4,5].map(dot => (
                              <div key={dot} style={{
                                width: 6, height: 6, borderRadius: "50%",
                                background: dot <= n.score[c] ? n.color : "#e8e0d8",
                                transition: "background 0.2s",
                              }} />
                            ))}
                          </div>
                        </td>
                      ))}
                      <td style={{ padding: "16px", textAlign: "center" }}>
                        <span style={{ fontSize: 16, fontWeight: 400, color: n.color }}>{total}</span>
                        <span style={{ fontSize: 10, color: "#b0a8a0" }}>/20</span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {/* Footer CTA */}
        <div style={{
          marginTop: 48,
          background: "#1a1a2e",
          borderRadius: 12,
          padding: "28px 32px",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          flexWrap: "wrap",
          gap: 16,
        }}>
          <div>
            <div style={{ fontSize: 14, color: "#f0ece4", marginBottom: 4 }}>Like a direction? Heart it above and let's go deeper.</div>
            <div style={{ fontSize: 12, color: "#4a4860" }}>Next: logo concept, colour palette, or competitor map</div>
          </div>
          <div style={{ fontSize: 28, color: "#2a2a4e" }}>→</div>
        </div>
      </div>
    </div>
  );
}
